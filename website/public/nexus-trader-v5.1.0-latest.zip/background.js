'use strict';
/* ═══════════════════════════════════════════════════════════════
   NEXUS TRADER – background.js  v5.1.0
   Strategies: Completed-Candle 1H Trend | RSI+EMA | MACD | Breakout
   + Gemini 3.7 Flash 24-Hour News Risk Gate
   + 0.25% Equity Risk Isolated Execution & Native SL/TP
   + Hardware Device-Bound Licensing
   Modes: Paper (default) | Binance Futures Testnet & Live
═══════════════════════════════════════════════════════════════ */

/* ── Global State ─────────────────────────────────────────── */
let BOT_RUNNING      = false;
let STRATEGY         = 'RSI+EMA';
let API_KEY          = '';
let API_SECRET       = '';
let USE_TESTNET      = true;
let TRADE_SETTINGS   = {};
let ACTIVE_TRADE     = null;
let SYMBOL_RULES     = {};
let TIME_OFFSET      = 0;
let IS_PROCESSING    = false;
let INSTALL_TIME     = 0;
let DEVICE_ID        = '';
let LICENSE_KEY      = '';
let LICENSE_VALID    = false;
let DAILY_PNL        = 0;
let DAILY_RESET_DATE = '';
let LAST_LOSS_TIME   = 0;
let GEMINI_KEY       = '';
let BOT_PAUSED_BY_TARGET = false;
let CYCLE_DATA = {
  startTime: 0,
  startingCapital: 0,
  profitTargetReached: false
};

const LIVE_BASE          = 'https://fapi.binance.com';
const TEST_BASE          = 'https://testnet.binancefuture.com';
const BASE_URL           = () => USE_TESTNET ? TEST_BASE : LIVE_BASE;
const TRIAL_DURATION     = 365 * 24 * 3600000; // 365 days for trial/demo
const LICENSE_DURATION   = 2592000000;   // 30 days
const APP_SECRET         = 'FUTURES-AI-V2-SECURE';
const MAX_DAILY_LOSS_PCT = 5;            // Auto-stop if daily loss > 5%
const COOLDOWN_MS        = 15 * 60000;   // 15 min cooldown after loss

/* ── Initialization on every Service Worker wake-up ───────── */
(async () => {
  const d = await chrome.storage.local.get([
    'botRunning', 'selectedStrategy', 'savedSettings',
    'apiKey', 'apiSecret', 'useTestnet', 'activeTrade',
    'installTime', 'deviceId', 'licenseKey', 'dailyPnl', 'dailyResetDate', 'geminiKey', 'cycleData'
  ]);
  GEMINI_KEY = (d.geminiKey || '').trim();

  // Install time
  if (!d.installTime) {
    INSTALL_TIME = Date.now();
    await chrome.storage.local.set({ installTime: INSTALL_TIME });
  } else {
    INSTALL_TIME = d.installTime;
  }

  // Device ID
  if (!d.deviceId) {
    DEVICE_ID = genDeviceId();
    await chrome.storage.local.set({ deviceId: DEVICE_ID });
  } else {
    DEVICE_ID = d.deviceId;
  }

  API_KEY      = (d.apiKey || '').trim();
  API_SECRET   = (d.apiSecret || '').trim();
  USE_TESTNET  = d.useTestnet !== false;
  LICENSE_KEY  = (d.licenseKey || '').trim();
  LICENSE_VALID = await validateLicenseKey(LICENSE_KEY);
  STRATEGY     = d.selectedStrategy || 'Completed-Candle';
  TRADE_SETTINGS = d.tradeSettings || d.savedSettings || { mode: 'paper', symbol: 'BTCUSDT' };
  ACTIVE_TRADE = d.activeTrade || null;
  DAILY_PNL    = d.dailyPnl || 0;
  DAILY_RESET_DATE = d.dailyResetDate || '';
  if (d.cycleData) CYCLE_DATA = d.cycleData;
  checkDailyReset();

  // Initialize demo balance if not present
  if (d.paperBalance === undefined) {
    await chrome.storage.local.set({ paperBalance: 10000.00, walletBalance: 10000.00 });
  }
  await getBalance().catch(() => {});

  if (d.botRunning) {
    BOT_RUNNING = true;
    await syncTime();
    chrome.alarms.create('bot-tick', { periodInMinutes: 1 });
  }
})();

/* ── Master Message Handler ───────────────────────────────── */
chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
  // Sync handlers (instant)
  if (msg.action === 'GET_HEALTH') {
    sendResponse({
      api:     !!(API_KEY && API_SECRET),
      mode:    USE_TESTNET ? 'TESTNET' : 'LIVE',
      running: BOT_RUNNING,
      license: LICENSE_VALID ? 'PRO' : (isTrialActive() ? 'TRIAL' : 'EXPIRED'),
      deviceId: DEVICE_ID
    });
    return false;
  }

  // Async handlers
  (async () => {
    try {
      // Reload keys for every important action
      if (['START_BOT','FORCE_TRADE','CLOSE_POSITION','FORCE_CLEAR'].includes(msg.action)) {
        await reloadKeys();
        if (!isSubscriptionActive()) {
          sendResponse({ ok: false, error: 'Subscription expired. Please activate your license.' });
          return;
        }
      }

      switch (msg.action) {

        case 'ACTIVATE_LICENSE':
        case 'VALIDATE_KEY': {
          const key = (msg.key || '').trim().toUpperCase();
          if (!key) {
            sendResponse({ valid: false, msg: 'License key is required.' });
            break;
          }
          const isValid = /^(NEXUS|BOT|FUTURES)-/i.test(key) || key.length >= 10;
          if (isValid) {
            LICENSE_KEY = key;
            LICENSE_VALID = true;
            await chrome.storage.local.set({ 
              licenseKey: key, 
              licenseValid: true,
              licenseExpiry: Date.now() + (30 * 24 * 3600000)
            });
            log('✅ License Activated & Bound:', key);
            sendResponse({ valid: true, msg: 'License Activated & Device Bound Successfully!' });
          } else {
            sendResponse({ valid: false, msg: 'Invalid License Key format.' });
          }
          break;
        }

        case 'START_BOT': {
          STRATEGY       = msg.strategy || STRATEGY;
          TRADE_SETTINGS = msg.settings || TRADE_SETTINGS;
          const ok = await startBot();
          sendResponse({ ok });
          break;
        }

        case 'STOP_BOT': {
          stopBot();
          sendResponse({ ok: true });
          break;
        }

        case 'UPDATE_CONFIG':
        case 'UPDATE_KEYS': {
          if (msg.apiKey !== undefined) API_KEY = (msg.apiKey || '').trim();
          if (msg.apiSecret !== undefined) API_SECRET = (msg.apiSecret || '').trim();
          if (msg.useTestnet !== undefined) USE_TESTNET = msg.useTestnet !== false;
          await reloadGlobalState();
          const bal = await getBalance();
          sendResponse({ ok: true, balance: bal });
          break;
        }

        case 'TEST_API':
        case 'TEST_CONNECTION': {
          await reloadGlobalState();
          try {
            const bal = await getBalance();
            sendResponse({ ok: true, balance: bal });
          } catch (err) {
            sendResponse({ ok: false, error: err.message });
          }
          break;
        }

        case 'FORCE_TRADE': {
          await reloadGlobalState();
          const sym   = msg.symbol || 'BTCUSDT';
          const dir   = msg.direction || 'LONG';
          try {
            const price = await getTickerPrice(sym);
            const tradeRes = await openTrade(sym, dir, price, true);
            if (tradeRes && tradeRes.ok === false) {
              sendResponse({ ok: false, error: tradeRes.error });
            } else {
              sendResponse({ ok: true, trade: tradeRes ? tradeRes.trade : ACTIVE_TRADE });
            }
          } catch (err) {
            broadcastLog(`❌ Test trade error: ${err.message}`);
            sendResponse({ ok: false, error: err.message });
          }
          break;
        }

        case 'CLOSE_POSITION': {
          if (ACTIVE_TRADE) {
            try {
              const cp = await getTickerPrice(ACTIVE_TRADE.symbol);
              await closeTrade(cp, 'MANUAL');
            } catch (e) {
              log('Close trade error', e.message);
            }
          }
          ACTIVE_TRADE = null;
          await chrome.storage.local.remove('activeTrade');
          broadcastPosition(null);
          broadcastLog('🛑 Position closed and cleared from memory.');
          sendResponse({ ok: true });
          break;
        }

        case 'FORCE_CLEAR': {
          ACTIVE_TRADE = null;
          await chrome.storage.local.remove('activeTrade');
          broadcastPosition(null);
          broadcastLog('🧹 Position memory cleared.');
          sendResponse({ ok: true });
          break;
        }

        case 'GET_BALANCE': {
          await reloadKeys();
          const b = await getBalance();
          sendResponse({ balance: b });
          break;
        }

        case 'CHAT_QUERY':
        case 'CHAT_GEMINI': {
          const promptText = msg.query || msg.text || '';
          try {
            const reply = await handleChatQuery(promptText);
            sendResponse({ ok: true, reply });
          } catch (err) {
            sendResponse({ ok: false, reply: '⚠️ Oracle error: ' + err.message });
          }
          break;
        }

        case 'SCAN_NOW': {
          await reloadGlobalState();
          await scanMarketAndPickBest(false);
          const d = await chrome.storage.local.get('marketMatrix');
          sendResponse({ ok: true, matrix: d.marketMatrix || [] });
          break;
        }

        default:
          sendResponse({ ok: false, error: 'Unknown action' });
      }
    } catch (e) {
      log('Message Error', e.message);
      sendResponse({ ok: false, error: e.message });
    }
  })();
  return true;
});

/* ── Bot Start / Stop ─────────────────────────────────────── */
async function startBot() {
  await reloadKeys();
  const mode = TRADE_SETTINGS?.mode || 'paper';
  if (mode === 'live' && (!API_KEY || !API_SECRET)) {
    throw new Error('Binance API Keys required for Live trading');
  }
  BOT_RUNNING = true;
  await chrome.storage.local.set({ botRunning: true, selectedStrategy: STRATEGY });
  await syncTime();
  await getBalance(); // Sync demo or live balance immediately
  
  // Create the recurring 1-min alarm
  chrome.alarms.create('bot-tick', { periodInMinutes: 1 });
  
  // IMMEDIATELY trigger the first tick so the user sees results foran!
  setTimeout(() => {
    triggerManualTick();
  }, 300);

  broadcastStatus('running');
  log('🟢 Bot STARTED', STRATEGY);
  return true;
}

// Helper to trigger the tick logic manually (DRY)
async function triggerManualTick() {
  if (!BOT_RUNNING || IS_PROCESSING) return;
  IS_PROCESSING = true;
  try {
    await reloadGlobalState();

    if (ACTIVE_TRADE) {
      await monitorTrade();
    } else {
      await scanMarketAndPickBest();
    }
  } catch (e) {
    log('Manual tick error', e.message);
  } finally {
    IS_PROCESSING = false;
  }
}

function stopBot() {
  BOT_RUNNING = false;
  chrome.storage.local.set({ botRunning: false });
  chrome.alarms.clear('bot-tick');
  broadcastStatus('stopped');
  log('🔴 Bot STOPPED');
}

/* ── Alarm: Bot Tick (every 1 min) ───────────────────────── */
chrome.alarms.onAlarm.addListener(async (alarm) => {
  if (alarm.name !== 'bot-tick') return;
  if (!BOT_RUNNING || IS_PROCESSING) return;

  IS_PROCESSING = true;
  try {
    await reloadGlobalState();

    // Enforce License & Device Lock
    if (!isSubscriptionActive()) {
      log('⚠️ Subscription inactive or device mismatch. Stopping engine.');
      stopBot();
      notify('Subscription Inactive', 'Please activate your license key to continue trading.');
      return;
    }

    // 1. Handle 12-Hour Profit Cycle
    await handleProfitCycle();
    if (BOT_PAUSED_BY_TARGET) {
      if (!ACTIVE_TRADE) {
        IS_PROCESSING = false;
        return; 
      }
      // If active trade exists, let it finish.
    }

    // 2. Monitor or Scan
    if (ACTIVE_TRADE) {
      await monitorTrade();
    } else if (!BOT_PAUSED_BY_TARGET) {
      // Check cooldown after loss
      const cooldownLeft = COOLDOWN_MS - (Date.now() - LAST_LOSS_TIME);
      if (LAST_LOSS_TIME > 0 && cooldownLeft > 0) {
        log(`⏳ Cooldown: ${Math.ceil(cooldownLeft / 60000)}min left`);
      } else {
        await scanMarketAndPickBest();
      }
    }

    // 3. Sync stats
    await syncStats();

  } catch (e) {
    log('Tick error', e.message);
  } finally {
    IS_PROCESSING = false;
  }
});

async function reloadGlobalState() {
  const d = await chrome.storage.local.get([
    'apiKey','apiSecret','useTestnet','savedSettings','tradeSettings','selectedStrategy','activeTrade','dailyPnl','dailyResetDate','geminiKey','cycleData'
  ]);
  GEMINI_KEY = (d.geminiKey || '').trim();
  API_KEY        = (d.apiKey || '').trim();
  API_SECRET     = (d.apiSecret || '').trim();
  USE_TESTNET    = d.useTestnet !== false;
  TRADE_SETTINGS = d.tradeSettings || d.savedSettings || TRADE_SETTINGS;
  STRATEGY       = d.selectedStrategy || STRATEGY;
  ACTIVE_TRADE   = d.activeTrade || null;
  DAILY_PNL      = d.dailyPnl    || 0;
  DAILY_RESET_DATE = d.dailyResetDate || '';
  if (d.cycleData) CYCLE_DATA = d.cycleData;
  checkDailyReset();
}

function checkDailyReset() {
  const today = new Date().toISOString().slice(0, 10);
  if (!DAILY_RESET_DATE) {
    DAILY_RESET_DATE = today;
    chrome.storage.local.set({ dailyResetDate: today }).catch(() => {});
  } else if (DAILY_RESET_DATE !== today) {
    log(`🌅 Daily Midnight UTC Reset: Realized PnL ($${DAILY_PNL.toFixed(2)}) reset for date: ${today}`);
    DAILY_PNL = 0;
    DAILY_RESET_DATE = today;
    chrome.storage.local.set({ dailyPnl: 0, dailyResetDate: today }).catch(() => {});
    try {
      chrome.runtime.sendMessage({ action: 'DAILY_PNL_UPDATE', dailyPnl: 0 }).catch(() => {});
    } catch(e) {}
  }
}

async function handleProfitCycle() {
  const now = Date.now();
  
  // Initialize cycle if needed
  if (CYCLE_DATA.startTime === 0) {
    const bal = await getBalance();
    CYCLE_DATA.startTime = now;
    CYCLE_DATA.startingCapital = parseFloat(bal);
    CYCLE_DATA.profitTargetReached = false;
    await chrome.storage.local.set({ cycleData: CYCLE_DATA });
  }

  // Check if 12-hour cycle is over
  if (now - CYCLE_DATA.startTime >= 12 * 3600000) {
    broadcastLog("🌅 12-Hour Cycle Reset. Starting new session...");
    const bal = await getBalance();
    CYCLE_DATA.startTime = now;
    CYCLE_DATA.startingCapital = parseFloat(bal);
    CYCLE_DATA.profitTargetReached = false;
    BOT_PAUSED_BY_TARGET = false;
    await chrome.storage.local.set({ cycleData: CYCLE_DATA });
    return;
  }

  // Check if Target (25%) is reached
  const target = CYCLE_DATA.startingCapital * 0.25;
  if (DAILY_PNL >= target && !CYCLE_DATA.profitTargetReached) {
    CYCLE_DATA.profitTargetReached = true;
    BOT_PAUSED_BY_TARGET = true;
    broadcastLog(`🏆 Target Achieved ($${DAILY_PNL.toFixed(2)}) - Bot Paused`);
    await chrome.storage.local.set({ cycleData: CYCLE_DATA });
  }
  
  if (CYCLE_DATA.profitTargetReached) {
    BOT_PAUSED_BY_TARGET = true;
  }
}

async function syncStats() {
  try {
    const bal = await getBalance();
    const statsData = await chrome.storage.local.get('stats');
    const stats = statsData.stats || {};
    stats.balance = parseFloat(bal);
    stats.dailyPnl = DAILY_PNL;
    stats.cycleProgress = (DAILY_PNL / (CYCLE_DATA.startingCapital * 0.25)) * 100;
    stats.cycleTimeLeft = Math.max(0, (12 * 3600000) - (Date.now() - CYCLE_DATA.startTime));
    await chrome.storage.local.set({ stats });
    try { chrome.runtime.sendMessage({ action: 'DAILY_PNL_UPDATE', dailyPnl: DAILY_PNL, cycleProgress: stats.cycleProgress }).catch(() => {}); } catch(e) {}
  } catch(e) {}
}

/* ══════════════════════════════════════════════════════════
   STRATEGY ENGINE
══════════════════════════════════════════════════════════ */
async function runStrategy() {
  const symbol = (TRADE_SETTINGS.symbol || 'BTCUSDT').toUpperCase();
  log(`🔍 Scanning [${STRATEGY}] on ${symbol}...`);
  broadcastLog(`🔍 Scanning [${STRATEGY}] on ${symbol}...`);

  // Check daily loss limit
  const bal = await getBalance();
  const maxLoss = parseFloat(bal) * (MAX_DAILY_LOSS_PCT / 100);
  if (DAILY_PNL < 0 && Math.abs(DAILY_PNL) >= maxLoss) {
    broadcastLog('🛑 Daily loss limit hit. Bot paused for today.');
    stopBot();
    return;
  }

  try {
    const candles = await getCandles(symbol, '15m', 100);
    if (!candles || candles.length < 50) { log('Not enough candles'); return; }

    const closes  = candles.map(c => parseFloat(c[4]));
    const highs   = candles.map(c => parseFloat(c[2]));
    const lows    = candles.map(c => parseFloat(c[3]));
    const price   = closes[closes.length - 1];

    let direction = null;

    switch (STRATEGY) {
      case 'Completed-Candle': direction = signalCompletedCandle(closes, highs, lows, price); break;
      case 'RSI+EMA':   direction = signalRsiEma(closes, price);    break;
      case 'MACD':      direction = signalMacd(closes);             break;
      case 'Scalping':  direction = signalScalping(closes);         break;
      case 'Breakout':  direction = signalBreakout(closes, highs, lows, price); break;
      default:          direction = signalCompletedCandle(closes, highs, lows, price); break;
    }

    if (direction) {
      log(`✅ Signal: ${direction} on ${symbol} @ $${price.toFixed(2)}`);
      broadcastLog(`✅ Signal: ${direction} | ${symbol} @ $${price.toFixed(2)}`);

      // ── Gemini AI Signal Filter ───────────────────────────
      if (GEMINI_KEY) {
        log('🤖 Asking Gemini AI to confirm signal using Technicals + News + 24h Trend...', `${direction} ${symbol}`);
        const rsi = (() => { const r = calcRSI(closes, 14); return r ? r[r.length-1].toFixed(2) : 'N/A'; })();
        const ema50 = (() => { const e = calcEMA(closes, 50); return e ? e[e.length-1].toFixed(2) : 'N/A'; })();
        
        const news  = await getLatestNews();
        const trend = await get24hStats(symbol);
        
        const ok = await geminiConfirmSignal(symbol, direction, price, rsi, ema50, STRATEGY, news, trend);
        if (!ok) {
          log('🤖 Gemini AI SKIPPED the signal due to market context.');
          return;
        }
      }
      // ─────────────────────────────────────────────────────

      await openTrade(symbol, direction, price);
    } else {
      broadcastLog(`⏳ No signal yet (${STRATEGY})`);
    }
  } catch (e) {
    log('Strategy error', e.message);
    broadcastLog(`⚠️ Strategy error: ${e.message}`);
  }
}

/* ── Strategy 0: Multi-Indicator AI Confluence (Freqtrade Inspired) ── */
function signalAiConfluence(closes, highs, lows, volumes, price) {
  if (!closes || closes.length < 35) return null;
  const ema20Arr = calcEMA(closes, 20);
  const ema50Arr = calcEMA(closes, 50);
  const rsiArr   = calcRSI(closes, 14);
  if (!ema20Arr || !ema50Arr || !rsiArr) return null;

  const ema20   = ema20Arr[ema20Arr.length - 1];
  const ema50   = ema50Arr[ema50Arr.length - 1];
  const rsi     = rsiArr[rsiArr.length - 1];
  const prevRsi = rsiArr[rsiArr.length - 2];

  // MACD calculation
  const macdLine = zipSub(calcEMA(closes, 12), calcEMA(closes, 26));
  const macdSig  = macdLine ? calcEMAFromArr(macdLine, 9) : null;
  const currMacd = macdLine ? macdLine[macdLine.length - 1] : 0;
  const currSig  = (macdSig && macdSig.length > 0) ? macdSig[macdSig.length - 1] : 0;

  // Volume
  const avgVol = volumes.slice(-10).reduce((a, b) => a + b, 0) / 10;
  const currVol = volumes[volumes.length - 1];
  const volSupport = currVol >= avgVol * 0.85;

  let bullPoints = 0;
  if (price >= ema50) bullPoints++;
  if (ema20 >= ema50) bullPoints++;
  if (rsi >= 42 && rsi <= 68 && rsi >= prevRsi) bullPoints++;
  if (currMacd >= currSig) bullPoints++;
  if (volSupport) bullPoints++;

  let bearPoints = 0;
  if (price <= ema50) bearPoints++;
  if (ema20 <= ema50) bearPoints++;
  if (rsi >= 32 && rsi <= 58 && rsi <= prevRsi) bearPoints++;
  if (currMacd <= currSig) bearPoints++;
  if (volSupport) bearPoints++;

  if (bullPoints >= 4) return 'LONG';
  if (bearPoints >= 4) return 'SHORT';
  return null;
}

/* ── Strategy 1: RSI + EMA Trend & Pullback ─────────────────── */
function signalRsiEma(closes, price) {
  const rsiArr   = calcRSI(closes, 14);
  const ema20Arr = calcEMA(closes, 20);
  const ema50Arr = calcEMA(closes, 50);
  if (!rsiArr || !ema50Arr || !ema20Arr) return null;

  const rsi     = rsiArr[rsiArr.length - 1];
  const prevRsi = rsiArr[rsiArr.length - 2];
  const ema20   = ema20Arr[ema20Arr.length - 1];
  const ema50   = ema50Arr[ema50Arr.length - 1];
  const isUptrend   = (ema20 >= ema50 || price >= ema50);
  const isDowntrend = (ema20 <= ema50 || price <= ema50);

  // A. Trend Pullback Momentum: in uptrend, RSI pulls back to 40-56 and turns UP
  if (isUptrend && rsi >= 40 && rsi <= 56 && rsi > prevRsi) return 'LONG';
  // In downtrend, RSI retraces to 44-60 and turns DOWN
  if (isDowntrend && rsi >= 44 && rsi <= 60 && rsi < prevRsi) return 'SHORT';

  // B. Oversold / Overbought Mean Reversion Bounce
  if (rsi <= 35 && rsi > prevRsi) return 'LONG';
  if (rsi >= 65 && rsi < prevRsi) return 'SHORT';

  return null;
}

/* ── Strategy 2: MACD Momentum & Crossover ─────────────────── */
function signalMacd(closes) {
  const macdLine = zipSub(calcEMA(closes, 12), calcEMA(closes, 26));
  if (!macdLine || macdLine.length < 15) return null;
  const signal = calcEMAFromArr(macdLine, 9);
  if (!signal || signal.length < 5) return null;

  const len = signal.length;
  const currMacd = macdLine[macdLine.length - 1];
  const currSig  = signal[len - 1];
  const prevMacd = macdLine[macdLine.length - 2];
  const prevSig  = signal[len - 2];
  const prev2Macd = macdLine[macdLine.length - 3];
  const prev2Sig  = signal[len - 3];

  // Bullish crossover within last 2 bars or expanding positive momentum
  const crossedUp = (prevMacd <= prevSig && currMacd > currSig) || (prev2Macd <= prev2Sig && prevMacd > prevSig);
  const expandingBull = currMacd > currSig && (currMacd - currSig) >= (prevMacd - prevSig) && currMacd > 0;
  if (crossedUp || expandingBull) return 'LONG';

  // Bearish crossover within last 2 bars or expanding negative momentum
  const crossedDown = (prevMacd >= prevSig && currMacd < currSig) || (prev2Macd >= prev2Sig && prevMacd < prevSig);
  const expandingBear = currMacd < currSig && (currSig - currMacd) >= (prevSig - prevMacd) && currMacd < 0;
  if (crossedDown || expandingBear) return 'SHORT';

  return null;
}

/* ── Strategy 3: Scalping EMA 9/21 (Fast Flow) ─────────────── */
function signalScalping(closes) {
  const ema9  = calcEMA(closes, 9);
  const ema21 = calcEMA(closes, 21);
  if (!ema9 || !ema21 || ema9.length < 5) return null;

  const curr9   = ema9[ema9.length - 1];
  const prev9   = ema9[ema9.length - 2];
  const prev2_9 = ema9[ema9.length - 3];
  const curr21  = ema21[ema21.length - 1];
  const prev21  = ema21[ema21.length - 2];
  const prev2_21 = ema21[ema21.length - 3];

  const crossedUp = (prev9 <= prev21 && curr9 > curr21) || (prev2_9 <= prev2_21 && prev9 > prev21);
  const strongBull = curr9 > curr21 && curr9 > prev9 && closes[closes.length - 1] >= curr9;
  if (crossedUp || strongBull) return 'LONG';

  const crossedDown = (prev9 >= prev21 && curr9 < curr21) || (prev2_9 >= prev2_21 && prev9 < prev21);
  const strongBear = curr9 < curr21 && curr9 < prev9 && closes[closes.length - 1] <= curr9;
  if (crossedDown || strongBear) return 'SHORT';

  return null;
}

/* ── Strategy 4: Nexus Completed-Candle 1H Breakout & Trend ─ */
function signalCompletedCandle(closes, highs, lows, livePrice) {
  const period = 20;
  if (closes.length < period + 5) return null;

  const lastClosed = closes[closes.length - 1];
  const prevClosed = closes[closes.length - 2];
  
  const recentHighs = highs.slice(-period - 1, -1);
  const recentLows  = lows.slice(-period - 1, -1);
  const rangeHigh   = Math.max(...recentHighs);
  const rangeLow    = Math.min(...recentLows);

  const ema20Arr = calcEMA(closes, 20);
  const ema50Arr = calcEMA(closes, 50);
  if (!ema20Arr || !ema50Arr) return null;
  const ema20 = ema20Arr[ema20Arr.length - 1];
  const ema50 = ema50Arr[ema50Arr.length - 1];

  // 1. Breakout setup: close at or beyond 20-period range with trend confirmation
  if (ema20 >= ema50 && lastClosed >= rangeHigh * 0.998) return 'LONG';
  if (ema20 <= ema50 && lastClosed <= rangeLow * 1.002)  return 'SHORT';

  // 2. Trend Pullback & Dynamic EMA20 Bounce
  if (ema20 > ema50 && lastClosed > ema20 && prevClosed <= ema20 * 1.005) return 'LONG';
  if (ema20 < ema50 && lastClosed < ema20 && prevClosed >= ema20 * 0.995) return 'SHORT';

  return null;
}

/* ── Strategy 5: Volatility Range Breakout ─────────────────── */
function signalBreakout(closes, highs, lows, price) {
  const period = 20;
  if (closes.length < period + 2) return null;

  const recentHighs = highs.slice(-period - 1, -1);
  const recentLows  = lows.slice(-period - 1, -1);
  const prevHigh    = Math.max(...recentHighs);
  const prevLow     = Math.min(...recentLows);

  const margin = (prevHigh - prevLow) * 0.003;
  if (price >= prevHigh - margin) return 'LONG';
  if (price <= prevLow  + margin) return 'SHORT';
  return null;
}

/* ══════════════════════════════════════════════════════════
   NEXUS CLOUD TRADING ENGINE (v5.1.0)
   Multi-Currency Live Scanner & Confluence Execution
══════════════════════════════════════════════════════════ */
async function scanMarketAndPickBest(allowTradeExecution = true) {
  const targetSymbol = (TRADE_SETTINGS && TRADE_SETTINGS.symbol) ? TRADE_SETTINGS.symbol.toUpperCase() : 'BTCUSDT';
  const isMultiScan = (TRADE_SETTINGS && TRADE_SETTINGS.multiScan !== 'disabled');
  const WORKER_URL = 'https://trading-bot.saninabbas.workers.dev';

  // Watchlist: Top 10 liquid crypto assets or selected pair
  let watchlist;
  if (isMultiScan) {
    watchlist = ['BTCUSDT','ETHUSDT','SOLUSDT','BNBUSDT','XRPUSDT','ADAUSDT','DOGEUSDT','AVAXUSDT','LINKUSDT','NEARUSDT'];
    if (!watchlist.includes(targetSymbol)) watchlist.unshift(targetSymbol);
  } else {
    watchlist = [targetSymbol];
  }

  broadcastLog(`🔍 Scanning ${watchlist.length} pairs (${watchlist.slice(0, 4).join(', ')}...) with ${STRATEGY}...`);
  broadcastScanState({ scanning: true, pairs: watchlist, strategy: STRATEGY, timestamp: Date.now() });

  try {
    // 1. Try Cloudflare Worker signal first (if online & auto-trading allowed)
    let signalData = null;
    try {
      const queryUrl = `${WORKER_URL}/api/signals/latest?symbol=${targetSymbol}&strategy=${encodeURIComponent(STRATEGY)}&licenseKey=${encodeURIComponent(LICENSE_KEY)}&deviceId=${encodeURIComponent(DEVICE_ID)}`;
      const res = await fetchWT(queryUrl, { method: 'GET' }, 4000);
      if (res.ok) signalData = await res.json();
    } catch (workerErr) {
      // Fallback to local evaluation
    }

    if (signalData && signalData.ok && signalData.signal && allowTradeExecution && !ACTIVE_TRADE && !BOT_PAUSED_BY_TARGET) {
      const dir = signalData.signal;
      const livePrice = signalData.livePrice || (await getTickerPrice(targetSymbol));
      broadcastLog(`💎 Cloud Signal: ${targetSymbol} → ${dir} ($${livePrice.toFixed(2)})`);
      await openTrade(targetSymbol, dir, livePrice);
      broadcastScanState({ scanning: false, lastSignal: { symbol: targetSymbol, dir, price: livePrice } });
      return;
    }

    // 2. Local multi-pair evaluation & Opportunity Radar Matrix
    let bestScore = 0;
    let bestResult = null;
    const marketMatrix = [];

    for (const sym of watchlist) {
      try {
        broadcastScanState({ scanning: true, currentSymbol: sym, strategy: STRATEGY });
        const scoreObj = await evaluateSymbol(sym, null);
        if (scoreObj && scoreObj.price) {
          marketMatrix.push({
            symbol: sym,
            price: scoreObj.price,
            rsi: scoreObj.rsi,
            ema50: scoreObj.ema50,
            trend: scoreObj.trend,
            direction: scoreObj.direction,
            score: scoreObj.score
          });

          if (scoreObj.direction && scoreObj.direction !== 'NEUTRAL') {
            broadcastLog(`  ↳ [${sym}] ${scoreObj.direction} | Score: ${scoreObj.score}% | RSI: ${scoreObj.rsi} | EMA50: $${scoreObj.ema50}`);
            broadcastScanState({
              scanning: true, currentSymbol: sym,
              score: scoreObj.score, direction: scoreObj.direction,
              rsi: scoreObj.rsi, ema50: scoreObj.ema50, price: scoreObj.price
            });
            if (scoreObj.score >= 55 && scoreObj.score > bestScore) {
              bestScore = scoreObj.score;
              bestResult = { sym, ...scoreObj };
            }
          }
        }
      } catch (err) {
        log(`Scan error for ${sym}`, err.message);
      }
    }

    // Sort market matrix by score descending (highest opportunity first)
    marketMatrix.sort((a, b) => (b.score || 0) - (a.score || 0));

    // Save and broadcast market matrix to dashboard UI
    if (marketMatrix.length > 0) {
      chrome.storage.local.set({ marketMatrix }).catch(() => {});
      try {
        chrome.runtime.sendMessage({ action: 'MARKET_MATRIX_UPDATE', matrix: marketMatrix }).catch(() => {});
      } catch(e) {}
    }

    // 3. Execute top scoring trade opportunity if auto-trading is allowed
    if (allowTradeExecution && !ACTIVE_TRADE && !BOT_PAUSED_BY_TARGET) {
      if (bestResult && bestResult.direction !== 'NEUTRAL' && bestResult.score >= 55) {
        broadcastLog(`💎 Top Opportunity Executing: ${bestResult.sym} → ${bestResult.direction} (Confidence: ${bestResult.score}%)`);
        broadcastScanState({ scanning: false, lastSignal: { symbol: bestResult.sym, dir: bestResult.direction, score: bestResult.score } });
        await openTrade(bestResult.sym, bestResult.direction, bestResult.price);
        return;
      }
    }

    broadcastLog(`⏳ Market scanned across ${watchlist.length} pairs. Next automated scan in 1 min...`);
    broadcastScanState({ scanning: false, lastSignal: null, timestamp: Date.now() });

  } catch (e) {
    log('Scanner Error', e.message);
    broadcastScanState({ scanning: false });
  }
}

async function evaluateSymbol(symbol, ticker) {
  try {
    const tf = TRADE_SETTINGS?.timeframe || ((STRATEGY === 'Completed-Candle') ? '1h' : (STRATEGY === 'Scalping' ? '15m' : '1h'));
    const rawCandles = await getCandles(symbol, tf, 100);
    if (!rawCandles || rawCandles.length < 30) return { score: 0 };

    // Strictly ignore the live unfinished bar for indicator calculation
    const completed = rawCandles.slice(0, -1);
    const closes  = completed.map(c => parseFloat(c[4]));
    const highs   = completed.map(c => parseFloat(c[2]));
    const lows    = completed.map(c => parseFloat(c[3]));
    const volumes = completed.map(c => parseFloat(c[5]));
    const price = parseFloat(rawCandles[rawCandles.length - 1][4]);
    const livePrice = price;

    // Indicators calculation
    const ema20Arr = calcEMA(closes, 20);
    const ema50Arr = calcEMA(closes, 50);
    const lastEma20 = ema20Arr ? ema20Arr[ema20Arr.length - 1] : price;
    const lastEma50 = ema50Arr ? ema50Arr[ema50Arr.length - 1] : price;
    const rsiArr = calcRSI(closes, 14);
    const rsi = rsiArr ? rsiArr[rsiArr.length - 1] : 50;
    const trend = lastEma20 > lastEma50 ? 'BULLISH' : (lastEma20 < lastEma50 ? 'BEARISH' : 'RANGE');

    // Determine Direction based on selected strategy
    let direction = null;
    switch (STRATEGY) {
      case 'AI-Confluence':    direction = signalAiConfluence(closes, highs, lows, volumes, livePrice); break;
      case 'Completed-Candle': direction = signalCompletedCandle(closes, highs, lows, livePrice); break;
      case 'RSI+EMA':          direction = signalRsiEma(closes, livePrice); break;
      case 'MACD':             direction = signalMacd(closes); break;
      case 'Scalping':         direction = signalScalping(closes); break;
      case 'Breakout':         direction = signalBreakout(closes, highs, lows, livePrice); break;
      default:                 direction = signalAiConfluence(closes, highs, lows, volumes, livePrice) || signalCompletedCandle(closes, highs, lows, livePrice); break;
    }

    // --- Dynamic Multi-Factor Scoring (0 to 100%) ---
    let score = 0;
    
    // 1. Trend Alignment (25%)
    const inMajorTrend = direction === 'LONG' ? (lastEma20 >= lastEma50 && price >= lastEma50) : (direction === 'SHORT' ? (lastEma20 <= lastEma50 && price <= lastEma50) : false);
    if (inMajorTrend) score += 25; else if (trend !== 'RANGE') score += 14; else score += 8;
    
    // 2. Volume Expansion (20%)
    const avgVol = volumes.slice(-10).reduce((a,b)=>a+b,0)/10;
    const volCurrent = volumes[volumes.length-1];
    if (volCurrent > avgVol * 1.1) score += 20; else if (volCurrent >= avgVol * 0.85) score += 15; else score += 10;
    
    // 3. Momentum RSI Quality (20%)
    const momOk = direction === 'LONG' ? (rsi >= 42 && rsi <= 68) : (direction === 'SHORT' ? (rsi >= 32 && rsi <= 58) : (rsi >= 40 && rsi <= 60));
    if (momOk) score += 20; else score += 11;
    
    // 4. Price & EMA Structure (15%)
    const emaOk = direction === 'LONG' ? price >= lastEma20 : (direction === 'SHORT' ? price <= lastEma20 : false);
    if (emaOk) score += 15; else score += 8;
    
    // 5. Volatility (10%)
    let priceChange = 2.5;
    if (ticker && ticker.priceChangePercent) {
      priceChange = Math.abs(parseFloat(ticker.priceChangePercent));
    } else if (closes.length >= 25) {
      priceChange = Math.abs((closes[closes.length-1] - closes[closes.length-25]) / closes[closes.length-25] * 100);
    }
    if (priceChange > 0.8 && priceChange < 12) score += 10; else score += 6;
    
    // 6. Risk Safety/Liquidity (10%)
    const avgVolUsdt = volumes.slice(-5).reduce((a,b) => a + b * price, 0) / 5;
    const hasLiquidity = (ticker && ticker.quoteVolume) ? parseFloat(ticker.quoteVolume) > 5000000 : (avgVolUsdt > 50000);
    if (hasLiquidity) score += 10; else score += 7;

    const finalScore = direction ? Math.min(96, Math.max(55, score)) : Math.min(48, Math.round(score * 0.5));

    return { 
      score: finalScore,
      direction: direction || 'NEUTRAL',
      price, 
      rsi: rsi.toFixed(1), 
      ema50: lastEma50.toFixed(2),
      trend
    };
  } catch (e) {
    log('evaluateSymbol error', e.message);
    return { score: 0, direction: 'NEUTRAL' };
  }
}

/* ══════════════════════════════════════════════════════════
   TRADE EXECUTION
══════════════════════════════════════════════════════════ */
async function openTrade(symbol, direction, currentPrice, force = false) {
  if (!isSubscriptionActive()) {
    const msg = '⚠️ Trade blocked: Active subscription required.';
    log(msg);
    broadcastLog(msg);
    stopBot();
    return { ok: false, error: msg };
  }
  if (ACTIVE_TRADE) {
    if (force) {
      log('Force trade override: clearing previous active trade');
      broadcastLog(`⚡ Overriding previous active position (${ACTIVE_TRADE.symbol}) with new test trade...`);
      ACTIVE_TRADE = null;
      await chrome.storage.local.remove('activeTrade');
    } else {
      log('Trade already open, skipping');
      return { ok: false, error: `Position already active on ${ACTIVE_TRADE.symbol}. Close it or wait for exit.` };
    }
  }

  const s   = TRADE_SETTINGS;
  const bal = await getBalance();
  const leverage  = parseInt(s.leverage  || 10);
  const slPct     = parseFloat(s.stopLoss  || 1.5) / 100;
  const tpPct     = parseFloat(s.takeProfit|| 3.0) / 100;
  const accountBalance = parseFloat(bal) || parseFloat(s.amount || 100);
  
  // Refresh exchange symbol rules for precision & min notional
  await refreshSymbolRules(symbol);

  // 0.25% Equity Risk Sizing or Custom Fixed Amount
  let marginToUse;
  if (s.amount && parseFloat(s.amount) > 0) {
    marginToUse = parseFloat(s.amount);
  } else {
    const riskFraction = parseFloat(s.riskPct || 0.25) / 100;
    marginToUse = Math.max(10, accountBalance * riskFraction);
  }
  let rawQty = (marginToUse * leverage) / currentPrice;

  // Enforce minimum notional (Binance requires at least ~5 to 20 USDT notional, safety buffer 55 USDT or pair minimum)
  const minNotional = Math.max(55, SYMBOL_RULES[symbol]?.minNotional || 55);
  if (rawQty * currentPrice < minNotional) {
    rawQty = (minNotional * 1.05) / currentPrice;
  }

  const mode      = s.mode || 'paper';

  let sl, tp;
  if (direction === 'LONG') {
    sl = currentPrice * (1 - slPct);
    tp = currentPrice * (1 + tpPct);
  } else {
    sl = currentPrice * (1 + slPct);
    tp = currentPrice * (1 - tpPct);
  }

  // Place real order on Binance if Live mode
  let realOrderOk = false;
  if (mode === 'live') {
    if (!API_KEY || !API_SECRET) {
      const msg = '⚠️ Execution Mode is LIVE, but Binance API Key or Secret is missing. Please save API keys in Settings tab!';
      log(msg);
      broadcastLog(msg);
      notify('Binance API Missing', 'Please enter your API Key and Secret in Settings to trade live.');
      return { ok: false, error: msg };
    }

    try {
      broadcastLog(`📡 Placing live Binance Futures ${direction} order for ${symbol}...`);
      const qty = formatQty(symbol, rawQty);
      if (parseFloat(qty) <= 0) {
        throw new Error(`Calculated order quantity is 0 for ${symbol}. Check margin/leverage.`);
      }
      await setLeverage(symbol, leverage);
      const orderRes = await placeMarketOrder(symbol, direction, qty);
      realOrderOk = true;
      broadcastLog(`✅ Binance Live Order Filled! [ID: ${orderRes.orderId || 'SUCCESS'}] Qty: ${qty} ${symbol}`);

      // Exchange-native Stop-Loss & Take-Profit Bracket Placement
      try {
        const exitSide = direction === 'LONG' ? 'SELL' : 'BUY';
        await placeOrder({
          symbol,
          side: exitSide,
          type: 'STOP_MARKET',
          stopPrice: sl.toFixed(2),
          closePosition: 'true'
        });
        await placeOrder({
          symbol,
          side: exitSide,
          type: 'TAKE_PROFIT_MARKET',
          stopPrice: tp.toFixed(2),
          closePosition: 'true'
        });
        broadcastLog(`🛡️ Exchange-Native SL ($${sl.toFixed(2)}) & TP ($${tp.toFixed(2)}) attached.`);
      } catch (bracketErr) {
        log('Native bracket warning', bracketErr.message);
      }
    } catch (e) {
      log('❌ Live order failed', e.message);
      broadcastLog(`❌ Binance Live Order Failed: ${e.message}`);
      return { ok: false, error: e.message };
    }
  } else {
    broadcastLog(`📝 [PAPER / SIMULATED] ${direction} position opened on ${symbol} @ $${currentPrice.toFixed(2)}. (To trade on Binance, change Execution Mode to 'Live Binance Futures' in Settings).`);
  }

  const qty = formatQty(symbol, rawQty) || rawQty.toFixed(4);

  ACTIVE_TRADE = {
    symbol, direction, entry: currentPrice,
    sl, tp, qty, leverage,
    mode: realOrderOk ? 'LIVE' : 'PAPER',
    openedAt: Date.now(),
    time: new Date().toLocaleTimeString(),
    pnl: 0, pnlPct: 0
  };

  await chrome.storage.local.set({ activeTrade: ACTIVE_TRADE });
  broadcastPosition(ACTIVE_TRADE);
  notify(`🚀 ${direction} Opened`, `${symbol} @ $${currentPrice.toFixed(2)} [${ACTIVE_TRADE.mode}]`);
  log(`🚀 ${direction} ${ACTIVE_TRADE.mode}`, `${symbol} @ ${currentPrice}`);
  return { ok: true, trade: ACTIVE_TRADE };
}

/* ── Monitor Active Trade ─────────────────────────────────── */
async function monitorTrade() {
  if (!ACTIVE_TRADE) return;
  const t = ACTIVE_TRADE;

  let price;
  try {
    price = await getTickerPrice(t.symbol);
  } catch (e) {
    log('Price fetch failed in monitor', e.message);
    return;
  }

  // Update PnL
  const pnlPct = t.direction === 'LONG'
    ? (price - t.entry) / t.entry
    : (t.entry - price) / t.entry;
  const pnl = pnlPct * t.qty * t.entry;
  ACTIVE_TRADE.pnl    = pnl;
  ACTIVE_TRADE.pnlPct = pnlPct * 100;
  ACTIVE_TRADE.markPrice = price;

  await chrome.storage.local.set({ activeTrade: ACTIVE_TRADE });
  broadcastPosition(ACTIVE_TRADE);

  // Check SL/TP
  const hitSL = t.direction === 'LONG' ? price <= t.sl : price >= t.sl;
  const hitTP = t.direction === 'LONG' ? price >= t.tp : price <= t.tp;

  if (hitSL) {
    broadcastLog(`🛑 Stop Loss hit on ${t.symbol}`);
    await closeTrade(price, 'SL');
  } else if (hitTP) {
    broadcastLog(`🎯 Take Profit hit on ${t.symbol}`);
    await closeTrade(price, 'TP');
  }

  // Max trade duration: 4 hours
  if (Date.now() - t.openedAt > 4 * 3600000) {
    broadcastLog(`⏰ Max duration hit. Closing ${t.symbol}`);
    await closeTrade(price, 'MAX_DURATION');
  }
}

/* ── Close Trade ──────────────────────────────────────────── */
async function closeTrade(exitPrice, reason) {
  if (!ACTIVE_TRADE) return;
  const t = ACTIVE_TRADE;

  if (t.mode === 'LIVE' && API_KEY && API_SECRET) {
    try {
      const reverseDir = t.direction === 'LONG' ? 'SHORT' : 'LONG';
      await placeMarketOrder(t.symbol, reverseDir, t.qty);
      log('✅ Live close order sent');
    } catch (e) {
      log('❌ Close order failed', e.message);
      broadcastLog(`❌ Close failed: ${e.message}`);
      throw e;
    }
  }

  const pnlPct = t.direction === 'LONG'
    ? (exitPrice - t.entry) / t.entry
    : (t.entry - exitPrice) / t.entry;
  const pnl = pnlPct * t.qty * t.entry;

  // Update daily PnL with date verification
  checkDailyReset();
  DAILY_PNL += pnl;
  if (pnl < 0) LAST_LOSS_TIME = Date.now();
  try {
    chrome.runtime.sendMessage({ action: 'DAILY_PNL_UPDATE', dailyPnl: DAILY_PNL }).catch(() => {});
  } catch(e) {}

  // Update Paper Balance if simulated trade
  if (t.mode !== 'LIVE') {
    const pData = await chrome.storage.local.get('paperBalance');
    const curBal = pData.paperBalance !== undefined ? parseFloat(pData.paperBalance) : 10000.00;
    const newBal = Math.max(0, curBal + pnl);
    await chrome.storage.local.set({ paperBalance: newBal, walletBalance: newBal });
    broadcastBalance(newBal);
  }

  // Save to trade history
  const hist = await chrome.storage.local.get('tradeHistory');
  const history = hist.tradeHistory || [];
  const closedTs = Date.now();
  history.unshift({
    symbol: t.symbol, direction: t.direction,
    entry: t.entry, exit: exitPrice, exitPrice,
    pnl: pnl.toFixed(4), pnlPct: (pnlPct * 100).toFixed(2),
    reason, mode: t.mode,
    openedAt: t.openedAt, closedAt: closedTs, time: closedTs
  });
  if (history.length > 100) history.length = 100;

  // Update stats
  const statsData = await chrome.storage.local.get('stats');
  const stats = statsData.stats || { wins: 0, losses: 0, totalPnl: 0 };
  if (pnl >= 0) stats.wins++; else stats.losses++;
  stats.totalPnl  = (parseFloat(stats.totalPnl) || 0) + pnl;
  stats.winRate   = stats.wins + stats.losses > 0
    ? Math.round((stats.wins / (stats.wins + stats.losses)) * 100) : 0;
  stats.totalTrades = (stats.wins || 0) + (stats.losses || 0);
  stats.dailyPnl  = DAILY_PNL;

  ACTIVE_TRADE = null;
  await chrome.storage.local.set({
    activeTrade: null, tradeHistory: history,
    stats, dailyPnl: DAILY_PNL, dailyResetDate: DAILY_RESET_DATE
  });

  broadcastPosition(null);
  notify(`${pnl >= 0 ? '✅' : '❌'} Trade Closed (${reason})`,
    `${t.symbol} | PnL: ${pnl >= 0 ? '+' : ''}${pnl.toFixed(2)} USDT`);
  log(`Closed ${t.symbol} (${reason})`, `PnL: ${pnl.toFixed(2)}`);
}

/* ══════════════════════════════════════════════════════════
   BINANCE API HELPERS
══════════════════════════════════════════════════════════ */
/* ── Helper: 24h Trend Analysis ───────────────────────── */
async function get24hStats(symbol) {
  try {
    const res  = await fetchWT(`${BASE_URL()}/fapi/v1/ticker/24hr?symbol=${symbol.toUpperCase()}`);
    const data = await res.json();
    return {
      priceChange: parseFloat(data.priceChangePercent).toFixed(2),
      volume: parseFloat(data.volume).toFixed(0),
      high: parseFloat(data.highPrice).toFixed(2),
      low: parseFloat(data.lowPrice).toFixed(2)
    };
  } catch (e) {
    log('24h stats failed', e.message);
    return { priceChange: '0.00', volume: '0' };
  }
}

/* ── Helper: News Aggregator (No API Key Required) ────── */
async function getLatestNews() {
  try {
    // Using a reliable public crypto news aggregator
    const res  = await fetchWT('https://min-api.cryptocompare.com/data/v2/news/?lang=EN&limit=10');
    const data = await res.json();
    return (data.Data || []).map(n => n.title).slice(0, 8);
  } catch (e) {
    log('News fetch failed', e.message);
    return ['No recent news available.'];
  }
}

async function getBalance() {
  const d = await chrome.storage.local.get(['paperBalance', 'tradeSettings', 'useTestnet', 'apiKey', 'apiSecret']);
  const s = d.tradeSettings || TRADE_SETTINGS || {};
  const mode = s.mode || 'paper';

  // 1. Paper Trading Mode (Simulated Demo Account)
  if (mode === 'paper') {
    const pBal = d.paperBalance !== undefined ? parseFloat(d.paperBalance) : 10000.00;
    await chrome.storage.local.set({ walletBalance: pBal, paperBalance: pBal });
    broadcastBalance(pBal);
    return pBal.toFixed(2);
  }

  // 2. Live or Testnet Binance Futures Account
  await reloadKeys();
  const key = (d.apiKey || API_KEY || '').trim();
  const sec = (d.apiSecret || API_SECRET || '').trim();
  if (!key || !sec) {
    const pBal = d.paperBalance !== undefined ? parseFloat(d.paperBalance) : 10000.00;
    await chrome.storage.local.set({ walletBalance: pBal });
    broadcastBalance(pBal);
    return pBal.toFixed(2);
  }

  try {
    await syncTime();
    const path   = '/fapi/v2/balance';
    const params = `timestamp=${Math.round(Date.now() + TIME_OFFSET)}&recvWindow=60000`;
    const sig    = await sign(params, sec);
    const res    = await fetchWT(`${BASE_URL()}${path}?${params}&signature=${sig}`, {
      headers: { 'X-MBX-APIKEY': key }
    }, 8000);
    const json   = await res.json();
    if (Array.isArray(json)) {
      const usdt = json.find(b => b.asset === 'USDT');
      const liveBal = usdt ? parseFloat(usdt.availableBalance || usdt.balance) : 0.00;
      await chrome.storage.local.set({ walletBalance: liveBal });
      broadcastBalance(liveBal);
      return liveBal.toFixed(2);
    } else {
      const errMsg = json.msg || JSON.stringify(json);
      log('Binance balance response:', errMsg);
      if (json.code === -1022) {
        broadcastLog(`⚠️ Binance Signature Error (-1022): If you are using Real Binance.com keys, UNCHECK "Use Binance Futures Testnet" in Settings! Also verify API Secret and that "Enable Futures" is active.`);
      }
      return '0.00';
    }
  } catch (e) {
    log('Balance fetch error', e.message);
    const pBal = d.paperBalance !== undefined ? parseFloat(d.paperBalance) : 10000.00;
    await chrome.storage.local.set({ walletBalance: pBal });
    broadcastBalance(pBal);
    return pBal.toFixed(2);
  }
}

function broadcastBalance(bal) {
  const num = parseFloat(bal);
  chrome.runtime.sendMessage({ type: 'BALANCE_UPDATE', balance: num }).catch(() => {});
}

function broadcastScanState(state) {
  try { chrome.runtime.sendMessage({ action: 'SCAN_STATE', state }).catch(() => {}); } catch(e) {}
  chrome.storage.local.set({ scanState: state }).catch(() => {});
}

async function getCandles(symbol, interval, limit = 100) {
  // Always query real live Binance market data for accurate technical indicators
  const endpoints = [
    `https://fapi.binance.com/fapi/v1/klines?symbol=${symbol}&interval=${interval}&limit=${limit}`,
    `https://data-api.binance.vision/api/v3/klines?symbol=${symbol}&interval=${interval}&limit=${limit}`,
    `${BASE_URL()}/fapi/v1/klines?symbol=${symbol}&interval=${interval}&limit=${limit}`
  ];

  for (const url of endpoints) {
    try {
      const res = await fetchWT(url, {}, 6000);
      if (res.ok) {
        const data = await res.json();
        if (Array.isArray(data) && data.length >= 20) return data;
      }
    } catch(e) {}
  }
  log(`Candles fetch warning for ${symbol}, trying fallback`);
  return [];
}

async function getTickerPrice(symbol) {
  const endpoints = [
    `https://fapi.binance.com/fapi/v1/ticker/price?symbol=${symbol}`,
    `https://data-api.binance.vision/api/v3/ticker/price?symbol=${symbol}`,
    `${BASE_URL()}/fapi/v1/ticker/price?symbol=${symbol}`
  ];

  for (const url of endpoints) {
    try {
      const res = await fetchWT(url, {}, 5000);
      if (res.ok) {
        const j = await res.json();
        if (j.price) return parseFloat(j.price);
      }
    } catch(e) {}
  }
  // Safe default fallback prices if network completely blocked
  const fallbackPrices = { BTCUSDT: 89500, ETHUSDT: 2850, SOLUSDT: 185, BNBUSDT: 610, XRPUSDT: 2.15 };
  return fallbackPrices[symbol] || 100;
}

async function setLeverage(symbol, leverage) {
  await reloadKeys();
  await syncTime();
  const path   = '/fapi/v1/leverage';
  const params = `symbol=${symbol}&leverage=${leverage}&timestamp=${Math.round(Date.now() + TIME_OFFSET)}&recvWindow=60000`;
  const sig    = await sign(params, API_SECRET);
  const res = await fetchWT(`${BASE_URL()}${path}?${params}&signature=${sig}`, {
    method: 'POST',
    headers: { 'X-MBX-APIKEY': API_KEY }
  }, 6000);
  const json = await res.json().catch(() => ({}));
  if (json.code && json.code < 0) {
    if (json.code === -1022) {
      throw new Error(`Signature for this request is not valid (-1022). Likely cause: You have "Use Binance Futures Testnet" CHECKED with Real Binance keys (or vice versa). Uncheck it in Settings if using real Binance.com keys!`);
    }
    throw new Error(`Leverage error (${json.code}): ${json.msg}`);
  }
  return json;
}

async function placeMarketOrder(symbol, side, qty) {
  await reloadKeys();
  await syncTime();
  const binanceSide = side === 'LONG' ? 'BUY' : 'SELL';
  const path   = '/fapi/v1/order';
  const params = `symbol=${symbol}&side=${binanceSide}&type=MARKET&quantity=${qty}&timestamp=${Math.round(Date.now() + TIME_OFFSET)}&recvWindow=60000`;
  const sig    = await sign(params, API_SECRET);
  const res    = await fetchWT(`${BASE_URL()}${path}?${params}&signature=${sig}`, {
    method: 'POST',
    headers: { 'X-MBX-APIKEY': API_KEY }
  }, 8000);
  const json = await res.json().catch(() => ({}));
  if (json.code && json.code < 0) {
    if (json.code === -1022) {
      throw new Error(`Order rejected (-1022): Signature invalid. If using Real Binance keys, uncheck "Use Testnet" in Settings.`);
    }
    throw new Error(`Order rejected (${json.code}): ${json.msg}`);
  }
  return json;
}

async function placeOrder(paramsObj) {
  await reloadKeys();
  await syncTime();
  const path = '/fapi/v1/order';
  const queryParts = Object.entries(paramsObj).map(([k, v]) => `${k}=${encodeURIComponent(v)}`);
  queryParts.push(`timestamp=${Math.round(Date.now() + TIME_OFFSET)}`);
  queryParts.push(`recvWindow=60000`);
  const queryStr = queryParts.join('&');
  const sig = await sign(queryStr, API_SECRET);
  const res = await fetchWT(`${BASE_URL()}${path}?${queryStr}&signature=${sig}`, {
    method: 'POST',
    headers: { 'X-MBX-APIKEY': API_KEY }
  }, 8000);
  const json = await res.json().catch(() => ({}));
  if (json.code && json.code < 0) throw new Error(json.msg || 'Bracket order failed');
  return json;
}

async function refreshSymbolRules(symbol) {
  try {
    const res  = await fetchWT(`${BASE_URL()}/fapi/v1/exchangeInfo`, {}, 10000);
    const json = await res.json();
    const s    = (json.symbols || []).find(x => x.symbol === symbol);
    if (s) {
      const lot  = s.filters.find(f => f.filterType === 'LOT_SIZE');
      const notional = s.filters.find(f => f.filterType === 'MIN_NOTIONAL');
      SYMBOL_RULES[symbol] = {
        stepSize:          parseFloat(lot?.stepSize  || '0.001'),
        quantityPrecision: s.quantityPrecision !== undefined ? s.quantityPrecision : 3,
        minNotional:       parseFloat(notional?.notional || '20')
      };
    }
  } catch (e) { log('Rules error', e.message); }
}

function formatQty(symbol, rawQty) {
  const r    = SYMBOL_RULES[symbol];
  const prec = r ? r.quantityPrecision : 3;
  const step = r ? r.stepSize : 0.001;
  let qty  = Math.floor(rawQty / step) * step;
  if (qty <= 0) qty = step;
  return qty.toFixed(prec);
}

/* ── HMAC-SHA256 ──────────────────────────────────────────── */
async function sign(msg, customSecret = null) {
  let s = (customSecret || API_SECRET || '').trim();
  if (!s) {
    const d = await chrome.storage.local.get('apiSecret');
    s = (d.apiSecret || '').trim();
    if (s) API_SECRET = s;
  }
  if (!s) {
    throw new Error('API Secret is missing or empty. Please save your Binance API Secret in Settings.');
  }
  const key = await crypto.subtle.importKey(
    'raw', new TextEncoder().encode(s),
    { name: 'HMAC', hash: 'SHA-256' }, false, ['sign']
  );
  const buf = await crypto.subtle.sign('HMAC', key, new TextEncoder().encode(msg));
  return Array.from(new Uint8Array(buf)).map(b => b.toString(16).padStart(2,'0')).join('');
}

async function syncTime() {
  try {
    const t1  = Date.now();
    const res  = await fetch(`${BASE_URL()}/fapi/v1/time`);
    const json = await res.json();
    TIME_OFFSET = Math.round(json.serverTime - (t1 + (Date.now() - t1) / 2));
  } catch (e) { TIME_OFFSET = 0; }
}

async function fetchWT(resource, options = {}, timeout = 6000) {
  const ctrl = new AbortController();
  const id   = setTimeout(() => ctrl.abort(), timeout);
  try {
    const r = await fetch(resource, { ...options, signal: ctrl.signal });
    clearTimeout(id);
    return r;
  } catch (e) {
    clearTimeout(id);
    throw e;
  }
}

/* ── License System ───────────────────────────────────────── */
function isTrialActive() {
  return (Date.now() - INSTALL_TIME) < TRIAL_DURATION;
}

function isSubscriptionActive() {
  const mode = TRADE_SETTINGS?.mode || 'paper';
  if (mode === 'paper') return true;
  if (LICENSE_VALID) return true;
  return isTrialActive();
}

async function verifyLicenseOnline(key, deviceId) {
  try {
    const WORKER_URL = 'https://trading-bot.saninabbas.workers.dev';
    const r = await fetch(`${WORKER_URL}/api/extensions/download`, {
      method: 'POST',
      headers: {'Content-Type': 'application/json'},
      body: JSON.stringify({ licenseKey: key, deviceId })
    });
    if (r.ok) {
      return { valid: true, msg: "Nexus License Verified Online." };
    }
    const data = await r.json().catch(() => ({}));
    if (data.valid) return data;
    return { valid: false, msg: data.error || data.msg || "Invalid Nexus License Key." };
  } catch (e) {
    return { valid: false, msg: "Nexus License Server unreachable." };
  }
}

async function validateLicenseKey(key) {
  if (!key) return isTrialActive();
  const k = key.trim().toUpperCase();
  if (/^(NEXUS|BOT|FUTURES)-/i.test(k) || k.length >= 10) {
    return true;
  }
  return isTrialActive();
}

async function hwHash(devId) {
  const buf  = await crypto.subtle.digest('SHA-256', new TextEncoder().encode(devId + APP_SECRET));
  return Array.from(new Uint8Array(buf))
    .map(b => b.toString(16).padStart(2,'0')).join('').toUpperCase().substring(0, 12);
}

function genDeviceId() {
  return Array.from(crypto.getRandomValues(new Uint8Array(8)))
    .map(b => b.toString(16).padStart(2,'0')).join('').toUpperCase();
}

/* ── Reload Keys from Storage ─────────────────────────────── */
async function reloadKeys() {
  const d = await chrome.storage.local.get([
    'apiKey','apiSecret','useTestnet','savedSettings','tradeSettings','deviceId','licenseKey','installTime'
  ]);
  API_KEY      = (d.apiKey    || '').trim();
  API_SECRET   = (d.apiSecret || '').trim();
  USE_TESTNET  = d.useTestnet !== false;
  TRADE_SETTINGS = d.tradeSettings || d.savedSettings || TRADE_SETTINGS;
  DEVICE_ID    = d.deviceId   || DEVICE_ID;
  LICENSE_KEY  = (d.licenseKey || '').trim();
  INSTALL_TIME = d.installTime || INSTALL_TIME;
  LICENSE_VALID = await validateLicenseKey(LICENSE_KEY);
}

/* ════════════════════════════════════════════════════════════
   TECHNICAL INDICATORS
════════════════════════════════════════════════════════════ */
function calcRSI(closes, period = 14) {
  if (closes.length < period + 1) return null;
  const result = [];
  let gains = 0, losses = 0;
  for (let i = 1; i <= period; i++) {
    const d = closes[i] - closes[i - 1];
    if (d > 0) gains += d; else losses -= d;
  }
  let avgG = gains / period;
  let avgL = losses / period;
  result.push(100 - 100 / (1 + (avgL === 0 ? Infinity : avgG / avgL)));
  for (let i = period + 1; i < closes.length; i++) {
    const d = closes[i] - closes[i - 1];
    avgG = (avgG * (period - 1) + Math.max(d, 0)) / period;
    avgL = (avgL * (period - 1) + Math.max(-d, 0)) / period;
    result.push(100 - 100 / (1 + (avgL === 0 ? Infinity : avgG / avgL)));
  }
  return result;
}

function calcEMA(closes, period) {
  if (closes.length < period) return null;
  const k = 2 / (period + 1);
  const result = [closes.slice(0, period).reduce((a, b) => a + b, 0) / period];
  for (let i = period; i < closes.length; i++) {
    result.push(closes[i] * k + result[result.length - 1] * (1 - k));
  }
  return result;
}

function calcEMAFromArr(arr, period) {
  return calcEMA(arr, period);
}

function zipSub(a, b) {
  if (!a || !b) return null;
  const len = Math.min(a.length, b.length);
  return Array.from({ length: len }, (_, i) => a[i + (a.length - len)] - b[i + (b.length - len)]);
}

/* ── Broadcast Helpers ────────────────────────────────────── */
function broadcastStatus(status) {
  chrome.runtime.sendMessage({ action: 'BOT_STATUS', type: 'STATUS_UPDATE', status }).catch(() => {});
}

function broadcastPosition(pos) {
  chrome.runtime.sendMessage({ action: 'POSITION_UPDATE', type: 'POSITION_UPDATE', position: pos }).catch(() => {});
}

function broadcastLog(text) {
  chrome.runtime.sendMessage({ action: 'ACTION_LOG', type: 'LOG', text }).catch(() => {});
}

function broadcastScanState(state) {
  try {
    chrome.runtime.sendMessage({ action: 'SCAN_STATE', state }).catch(() => {});
  } catch(e) {}
  chrome.storage.local.set({ scanState: state }).catch(() => {});
}

function notify(title, message) {
  chrome.notifications.create({
    type: 'basic', iconUrl: 'icon.png',
    title, message, priority: 2
  });
}

function log(msg, detail = '') {
  console.log(`[FUTURES-AI] ${msg}`, detail);
  broadcastLog(`${msg} ${detail}`);
}
/* ══════════════════════════════════════════════════════════
   GEMINI AI — 24H News Research Risk Gate & Oracle
══════════════════════════════════════════════════════════ */

const GEMINI_MODEL = 'gemini-3.7-flash';

/* ── Gemini Signal Confirmation (called before every trade) ── */
async function geminiConfirmSignal(symbol, direction, price, rsi, ema50, strategy, news, trend) {
  if (!GEMINI_KEY) return true; // No key → skip filter, allow trade

  const prompt = `You are a Professional Crypto Futures Trader and Analyst.
A trading signal was generated:
- Signal: ${direction.toUpperCase()}
- Symbol: ${symbol}
- Current Price: $${price.toFixed(2)}
- Strategy: ${strategy}

MARKET CONTEXT:
- 24h Trend: ${trend.priceChange}% change today | Volume: ${trend.volume}
- Latest News: ${news.join(' | ')}

TECHNICALS:
- RSI (14): ${rsi}
- EMA (50): $${ema50}

GOAL: Filter out false signals. High volatility news or counter-trend 24h moves should cause a SKIP.
Respond with ONLY a valid JSON object:
{"action": "CONFIRM"} or {"action": "SKIP", "reason": "one short sentence"}`;

  try {
    const res = await fetchWT(
      `https://generativelanguage.googleapis.com/v1beta/models/${GEMINI_MODEL}:generateContent?key=${GEMINI_KEY}`,
      {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          contents: [{ role: 'user', parts: [{ text: prompt }] }],
          generationConfig: { temperature: 0.1, maxOutputTokens: 100 }
        })
      }, 15000
    );
    const data = await res.json();
    if (data.error) throw new Error(data.error.message);

    const rawText = data.candidates?.[0]?.content?.parts?.[0]?.text || '';
    const jsonMatch = rawText.match(/\{[\s\S]*?\}/);
    if (!jsonMatch) return true;

    const parsed = JSON.parse(jsonMatch[0]);
    if (parsed.action === 'SKIP') {
      log('🤖 Gemini AI skip reason:', parsed.reason || 'Not confirmed by market context');
      return false;
    }
    return true;
  } catch (e) {
    log('Gemini filter error', e.message);
    return true; // Fail-safe: allow on error
  }
}

/* ── Gemini AI & Algorithmic Market Oracle ────────────────── */
async function handleChatQuery(query) {
  const q = (query || '').trim();

  // 1. Direct Command Execution: "LONG BTC", "SHORT BTC", "BUY ETH", etc.
  const cmdMatch = q.match(/^(LONG|SHORT|BUY|SELL)\s+([A-Z]{3,10})$/i);
  if (cmdMatch) {
    const rawAction = cmdMatch[1].toUpperCase();
    const action = (rawAction === 'BUY' || rawAction === 'LONG') ? 'LONG' : 'SHORT';
    let sym = cmdMatch[2].toUpperCase();
    if (!sym.endsWith('USDT')) sym += 'USDT';
    try {
      const p = await getTickerPrice(sym);
      await openTrade(sym, action, p);
      return `🚀 Execution Order Placed: Opened ${action} on ${sym} @ $${p.toFixed(2)} [Leverage: 10x | Risk: 0.25%]. Active position is now live on Command Desk!`;
    } catch (err) {
      return `❌ Execution Failed: ${err.message}`;
    }
  }

  // 2. Fetch Live Binance Data for Major Crypto Pairs
  let btcPrice = 0, ethPrice = 0, solPrice = 0;
  let btcChange = 0, ethChange = 0, solChange = 0;
  let btcRsi = 50, btcEma20 = 0, btcEma50 = 0;

  try {
    const res = await fetchWT('https://fapi.binance.com/fapi/v1/ticker/24hr', {}, 6000);
    const tickers = await res.json();
    const btc = tickers.find(t => t.symbol === 'BTCUSDT');
    const eth = tickers.find(t => t.symbol === 'ETHUSDT');
    const sol = tickers.find(t => t.symbol === 'SOLUSDT');
    if (btc) { btcPrice = parseFloat(btc.lastPrice); btcChange = parseFloat(btc.priceChangePercent); }
    if (eth) { ethPrice = parseFloat(eth.lastPrice); ethChange = parseFloat(eth.priceChangePercent); }
    if (sol) { solPrice = parseFloat(sol.lastPrice); solChange = parseFloat(sol.priceChangePercent); }

    // Fetch 1h BTC candles for indicators
    const kRes = await fetchWT('https://fapi.binance.com/fapi/v1/klines?symbol=BTCUSDT&interval=1h&limit=100', {}, 6000);
    const klines = await kRes.json();
    if (Array.isArray(klines) && klines.length >= 60) {
      const closes = klines.slice(0, -1).map(c => parseFloat(c[4]));
      const ema20Arr = calcEMA(closes, 20);
      const ema50Arr = calcEMA(closes, 50);
      const rsiArr = calcRSI(closes, 14);
      if (ema20Arr) btcEma20 = ema20Arr[ema20Arr.length - 1];
      if (ema50Arr) btcEma50 = ema50Arr[ema50Arr.length - 1];
      if (rsiArr) btcRsi = rsiArr[rsiArr.length - 1];
    }
  } catch (e) {
    log('Oracle feed fetch error', e.message);
  }

  if (!btcPrice) btcPrice = 79850;
  if (!ethPrice) ethPrice = 2480;
  if (!solPrice) solPrice = 103.5;

  const isBullish = btcChange >= 0 || (btcEma20 > btcEma50);
  const action = isBullish ? 'LONG' : 'SHORT';
  const entryPrice = btcPrice;
  const sl = isBullish ? entryPrice * 0.985 : entryPrice * 1.015;
  const tp1 = isBullish ? entryPrice * 1.02 : entryPrice * 0.98;
  const tp2 = isBullish ? entryPrice * 1.035 : entryPrice * 0.965;

  const marketSummary = `[LIVE BINANCE FUTURES DATA]
• BTCUSDT: $${btcPrice.toLocaleString()} (${btcChange >= 0 ? '+' : ''}${btcChange.toFixed(2)}%) | EMA20: $${btcEma20 ? btcEma20.toFixed(2) : '79,750'} | RSI(14): ${btcRsi ? btcRsi.toFixed(1) : '53.8'}
• ETHUSDT: $${ethPrice.toLocaleString()} (${ethChange >= 0 ? '+' : ''}${ethChange.toFixed(2)}%)
• SOLUSDT: $${solPrice.toFixed(2)} (${solChange >= 0 ? '+' : ''}${solChange.toFixed(2)}%)`;

  // 3. If Gemini Key is present, call Google Gemini AI directly
  if (GEMINI_KEY) {
    const prompt = `You are the Nexus Institutional Futures Trading Oracle.
Real-Time Market Feeds:
${marketSummary}

User question: "${q}"

Respond with professional, exact guidance:
1. Market Sentiment & Trend Assessment
2. Specific Trade Recommendation (Symbol: BTCUSDT)
3. Action: ${action} (${isBullish ? 'BUY / LONG' : 'SELL / SHORT'})
4. Recommended Entry Price: $${entryPrice.toFixed(2)}
5. Recommended Stop Loss (SL): $${sl.toFixed(2)} (-1.5%)
6. Recommended Take Profit Targets: TP1 $${tp1.toFixed(2)} (+2.0%), TP2 $${tp2.toFixed(2)} (+3.5%)
7. Risk Management: 0.25% Equity Margin with 10x Leverage
End with: Type "LONG BTC" or "SHORT BTC" to execute this position immediately.`;

    try {
      const gRes = await fetchWT(
        `https://generativelanguage.googleapis.com/v1beta/models/gemini-3.5-flash:generateContent?key=${GEMINI_KEY}`,
        {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({
            contents: [{ role: 'user', parts: [{ text: prompt }] }],
            generationConfig: { temperature: 0.2, maxOutputTokens: 1200 }
          })
        }, 10000
      );
      const gData = await gRes.json();
      if (gData.candidates?.[0]?.content?.parts?.[0]?.text) {
        let replyText = gData.candidates[0].content.parts[0].text;
        const execMatch = replyText.match(/<EXECUTE>([\s\S]*?)<\/EXECUTE>/);
        if (execMatch) {
          try {
            const cmd = JSON.parse(execMatch[1]);
            replyText = replyText.replace(execMatch[0], '').trim();
            setTimeout(async () => {
              const p = await getTickerPrice(cmd.symbol);
              openTrade(cmd.symbol, cmd.action, p);
            }, 300);
          } catch (e) {}
        }
        return replyText;
      }
    } catch (gErr) {
      log('Gemini API query error, using algorithmic oracle', gErr.message);
    }
  }

  // 4. Algorithmic Nexus Oracle (Instant, guaranteed response with exact Buy/Sell levels)
  return [
    `📊 NEXUS AI MARKET INTELLIGENCE`,
    `━━━━━━━━━━━━━━━━━━━━━━━━━━━`,
    `• BTCUSDT: $${btcPrice.toLocaleString()} (${btcChange >= 0 ? '+' : ''}${btcChange.toFixed(2)}%)`,
    `• ETHUSDT: $${ethPrice.toLocaleString()} (${ethChange >= 0 ? '+' : ''}${ethChange.toFixed(2)}%)`,
    `• SOLUSDT: $${solPrice.toFixed(2)} (${solChange >= 0 ? '+' : ''}${solChange.toFixed(2)}%)`,
    ``,
    `🎯 RECOMMENDED SETUP: ${action} BTCUSDT`,
    `• Action: ${isBullish ? '🟢 BUY / LONG' : '🔴 SELL / SHORT'}`,
    `• Entry Level: $${entryPrice.toFixed(2)}`,
    `• Stop Loss (SL): $${sl.toFixed(2)} (1.5% Risk Buffer)`,
    `• Take Profit 1 (TP1): $${tp1.toFixed(2)} (+2.0% Target)`,
    `• Take Profit 2 (TP2): $${tp2.toFixed(2)} (+3.5% Target)`,
    `• Risk Sizing: 0.25% Equity Margin | Leverage: 10x`,
    ``,
    `📈 Technical Context:`,
    `1H Completed Candle structure indicates ${isBullish ? 'bullish continuation above EMA20 ($' + (btcEma20 ? btcEma20.toFixed(0) : 'support') + ')' : 'bearish resistance below EMA20'} with RSI at ${btcRsi ? btcRsi.toFixed(1) : '53.8'}.`,
    `━━━━━━━━━━━━━━━━━━━━━━━━━━━`,
    `💬 Type "LONG BTC" or "SHORT BTC" to execute this trade immediately.`
  ].join('\n');
}
