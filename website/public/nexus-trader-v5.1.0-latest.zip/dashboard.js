'use strict';
/* ══════════════════════════════════════════════════════════════════════
   NEXUS TRADER v5.1.0 — Dashboard Controller
══════════════════════════════════════════════════════════════════════ */

let ACTIVE_TAB = 'overview';
let CYCLE_TIMER_INTERVAL = null;

document.addEventListener('DOMContentLoaded', async () => {
  initTabs();
  initListeners();
  await loadInitialState();
  initLiveUpdates();
});

/* ── Navigation Tabs ──────────────────────────────────────────────── */
function initTabs() {
  document.querySelectorAll('.nav-item').forEach(item => {
    item.addEventListener('click', (e) => {
      e.preventDefault();
      const target = item.getAttribute('data-tab');
      switchTab(target);
    });
  });
}

function switchTab(tabId) {
  document.querySelectorAll('.nav-item').forEach(n => n.classList.remove('active'));
  document.querySelectorAll('.tab-pane').forEach(p => p.classList.remove('active'));

  const navItem = document.querySelector(`.nav-item[data-tab="${tabId}"]`);
  const pane = document.getElementById(`tab-${tabId}`);
  if (navItem) navItem.classList.add('active');
  if (pane) pane.classList.add('active');
  ACTIVE_TAB = tabId;
}

/* ── State Loading ────────────────────────────────────────────────── */
async function loadInitialState() {
  try {
    const data = await chrome.storage.local.get(null);

    // Fallback / Restore from indelible localStorage backup if chrome.storage was cleared
    const localApiKey = localStorage.getItem('nexus_apiKey');
    const localApiSecret = localStorage.getItem('nexus_apiSecret');
    const localLicenseKey = localStorage.getItem('nexus_licenseKey');
    const localDeviceId = localStorage.getItem('nexus_deviceId');
    const localUseTestnet = localStorage.getItem('nexus_useTestnet');
    const localTradeSettings = localStorage.getItem('nexus_tradeSettings');

    const toRestore = {};
    if (!data.apiKey && localApiKey) {
      data.apiKey = localApiKey;
      toRestore.apiKey = localApiKey;
    }
    if (!data.apiSecret && localApiSecret) {
      data.apiSecret = localApiSecret;
      toRestore.apiSecret = localApiSecret;
    }
    if (!data.licenseKey && localLicenseKey) {
      data.licenseKey = localLicenseKey;
      toRestore.licenseKey = localLicenseKey;
      toRestore.licenseValid = true;
    }
    if (!data.deviceId) {
      const devId = localDeviceId || 'DEV-' + Math.random().toString(36).substring(2, 10).toUpperCase();
      data.deviceId = devId;
      toRestore.deviceId = devId;
      localStorage.setItem('nexus_deviceId', devId);
    } else {
      localStorage.setItem('nexus_deviceId', data.deviceId);
    }
    if (data.useTestnet === undefined && localUseTestnet !== null) {
      data.useTestnet = localUseTestnet === 'true';
      toRestore.useTestnet = data.useTestnet;
    }
    if (!data.tradeSettings && localTradeSettings) {
      try {
        data.tradeSettings = JSON.parse(localTradeSettings);
        toRestore.tradeSettings = data.tradeSettings;
      } catch (e) {}
    }

    if (Object.keys(toRestore).length > 0) {
      await chrome.storage.local.set(toRestore);
      chrome.runtime.sendMessage({ action: 'UPDATE_CONFIG', ...toRestore });
    }

    // Sync current values to localStorage backup
    if (data.apiKey) localStorage.setItem('nexus_apiKey', data.apiKey);
    if (data.apiSecret) localStorage.setItem('nexus_apiSecret', data.apiSecret);
    if (data.licenseKey) localStorage.setItem('nexus_licenseKey', data.licenseKey);
    if (data.useTestnet !== undefined) localStorage.setItem('nexus_useTestnet', data.useTestnet);
    if (data.tradeSettings) localStorage.setItem('nexus_tradeSettings', JSON.stringify(data.tradeSettings));
    
    // 1. Health Status
    updateHealth(data);

    // 2. Metrics & Settings
    updateMetrics(data);

    // Daily P&L from storage
    if (data.dailyPnl !== undefined) updateDailyPnl(data.dailyPnl);
    if (data.stats && data.stats.dailyPnl !== undefined) updateDailyPnl(data.stats.dailyPnl);

    // Scan panel state
    if (data.scanState) updateScanPanel(data.scanState);
    const scanPanel = document.getElementById('scan-analysis-panel');
    if (scanPanel) scanPanel.style.display = data.botRunning ? '' : 'none';

    // Fetch and sync fresh balance
    chrome.runtime.sendMessage({ action: 'GET_BALANCE' }, (resp) => {
      if (resp && resp.balance !== undefined) {
        const balEl = document.getElementById('ov-balance');
        if (balEl) balEl.textContent = `${parseFloat(resp.balance).toFixed(2)} USDT`;
      }
    });


    // 3. Populate Settings Form
    const s = data.tradeSettings || {};
    if (document.getElementById('symbol-input')) document.getElementById('symbol-input').value = s.symbol || 'BTCUSDT';
    if (document.getElementById('amount-input')) document.getElementById('amount-input').value = s.amount || '100';
    if (document.getElementById('strategy-input')) document.getElementById('strategy-input').value = data.selectedStrategy || 'AI-Confluence';
    if (document.getElementById('leverage-input')) document.getElementById('leverage-input').value = s.leverage || '10';
    if (document.getElementById('sl-input')) document.getElementById('sl-input').value = s.stopLoss || '1.5';
    if (document.getElementById('mode-input')) document.getElementById('mode-input').value = s.mode || 'paper';
    if (document.getElementById('multiscan-input')) document.getElementById('multiscan-input').value = s.multiScan || 'enabled';
    if (document.getElementById('timeframe-input')) document.getElementById('timeframe-input').value = s.timeframe || '1h';

    // Opportunity Radar Matrix: render cached or scan live immediately
    if (data.marketMatrix && data.marketMatrix.length > 0) {
      updateMarketMatrix(data.marketMatrix);
    } else {
      chrome.runtime.sendMessage({ action: 'SCAN_NOW' }, (resp) => {
        if (resp && resp.matrix) updateMarketMatrix(resp.matrix);
      });
    }

    // 4. API Keys
    if (data.apiKey && document.getElementById('api-key-input')) {
      document.getElementById('api-key-input').value = data.apiKey;
    }
    if (data.apiSecret && document.getElementById('api-secret-input')) {
      document.getElementById('api-secret-input').value = data.apiSecret;
    }
    if (document.getElementById('testnet-toggle')) {
      document.getElementById('testnet-toggle').checked = data.useTestnet === true;
      updateTestnetHint();
    }
    if (data.geminiKey && document.getElementById('gemini-key-input')) {
      document.getElementById('gemini-key-input').value = data.geminiKey;
    }

    // Update API Saved Banner & Save Button UI
    const apiSavedBanner = document.getElementById('api-saved-banner');
    const saveApiBtn = document.getElementById('save-api-btn');
    if (data.apiKey && data.apiSecret) {
      if (apiSavedBanner) apiSavedBanner.classList.remove('hidden');
      if (saveApiBtn) {
        saveApiBtn.textContent = '✓ Keys Permanently Saved';
        saveApiBtn.style.background = 'rgba(16,185,129,0.2)';
        saveApiBtn.style.borderColor = 'var(--lime)';
        saveApiBtn.style.color = 'var(--lime)';
      }
    } else {
      if (apiSavedBanner) apiSavedBanner.classList.add('hidden');
    }

    // 5. Device ID & Licence
    if (document.getElementById('device-id-display')) {
      document.getElementById('device-id-display').value = data.deviceId;
    }
    if (data.licenseKey && document.getElementById('license-key-input')) {
      document.getElementById('license-key-input').value = data.licenseKey;
    }

    // Update License Active Banner & Button UI
    const licBanner = document.getElementById('license-active-banner');
    const licTag = document.getElementById('license-saved-tag');
    const actBtn = document.getElementById('activate-btn');
    const licMsg = document.getElementById('license-status-msg');
    if (data.licenseKey) {
      if (licBanner) licBanner.classList.remove('hidden');
      if (licTag) licTag.classList.remove('hidden');
      if (actBtn) {
        actBtn.textContent = 'Licence Active ✓';
        actBtn.style.background = 'rgba(16,185,129,0.2)';
        actBtn.style.borderColor = 'var(--lime)';
        actBtn.style.color = 'var(--lime)';
      }
      if (licMsg) {
        licMsg.classList.remove('hidden');
        licMsg.textContent = '✅ Permanent Licence Verified & Bound to this Device.';
        licMsg.style.color = 'var(--lime)';
        licMsg.style.background = 'rgba(16,185,129,0.08)';
        licMsg.style.border = '1px solid rgba(16,185,129,0.3)';
        licMsg.style.padding = '10px 14px';
        licMsg.style.borderRadius = '6px';
      }
      // Show expiry info if stored
      const expiryEl = document.getElementById('lic-expiry');
      const daysEl   = document.getElementById('lic-days');
      if (data.licenseExpiry && expiryEl && daysEl) {
        const expDate = new Date(data.licenseExpiry);
        const daysLeft = Math.ceil((expDate - Date.now()) / 86400000);
        expiryEl.textContent = expDate.toLocaleDateString('en-GB', { day: '2-digit', month: 'short', year: 'numeric' });
        daysEl.textContent = daysLeft > 0 ? `${daysLeft}d` : 'Expired';
        daysEl.style.color = daysLeft > 7 ? 'var(--lime)' : daysLeft > 0 ? 'var(--amber)' : 'var(--red)';
      }
    }

    // 6. Active Position
    renderPosition(data.activeTrade);

    // 7. History
    renderHistory(data.tradeHistory || []);

    // 8. Start Cycle Timer
    startCycleTimer(data.cycleData);

    // 9. Engine Toggle Button
    updateBotToggleButton(data.botRunning === true);

  } catch (e) {
    console.error('Error loading initial state:', e);
  }
}

/* ── Live Updates & Port Messaging ────────────────────────────────── */
function initLiveUpdates() {
  chrome.storage.onChanged.addListener((changes) => {
    if (changes.activeTrade) renderPosition(changes.activeTrade.newValue);
    if (changes.tradeHistory) renderHistory(changes.tradeHistory.newValue || []);
    if (changes.botRunning) {
      const isRun = changes.botRunning.newValue === true;
      updateBotToggleButton(isRun);
      const statusEl = document.getElementById('ov-status');
      if (statusEl) {
        statusEl.textContent = isRun ? 'ACTIVE SCANNING' : 'STANDBY';
        statusEl.style.color = isRun ? 'var(--lime)' : 'var(--amber)';
      }
      // Hide scan panel when bot stops
      const scanPanel = document.getElementById('scan-analysis-panel');
      if (scanPanel) scanPanel.style.display = isRun ? '' : 'none';
    }
    if (changes.cycleData) startCycleTimer(changes.cycleData.newValue);
    if (changes.scanState) updateScanPanel(changes.scanState.newValue);
    if (changes.dailyPnl) updateDailyPnl(changes.dailyPnl.newValue);
    if (changes.stats) {
      const stats = changes.stats.newValue;
      if (stats && stats.dailyPnl !== undefined) updateDailyPnl(stats.dailyPnl);
    }
    if (changes.marketMatrix) updateMarketMatrix(changes.marketMatrix.newValue);
  });

  chrome.runtime.onMessage.addListener((msg) => {
    if (msg.action === 'ACTION_LOG' || msg.type === 'LOG') appendLog(msg.text);
    if (msg.action === 'POSITION_UPDATE' || msg.type === 'POSITION_UPDATE') renderPosition(msg.position);
    if (msg.action === 'BOT_STATUS' || msg.type === 'STATUS_UPDATE') updateHealth(msg.status);
    if (msg.action === 'SCAN_STATE') updateScanPanel(msg.state);
    if (msg.action === 'MARKET_MATRIX_UPDATE' || msg.action === 'MARKET_MATRIX') updateMarketMatrix(msg.matrix);
    if (msg.action === 'DAILY_PNL_UPDATE') {
      updateDailyPnl(msg.dailyPnl);
      if (msg.cycleProgress !== undefined) {
        const bar = document.getElementById('target-progress-bar');
        if (bar) bar.style.width = `${Math.min(100, Math.max(0, msg.cycleProgress))}%`;
      }
    }

  });
}

function updateMarketMatrix(matrix) {
  const tbody = document.getElementById('matrix-tbody');
  if (!tbody || !Array.isArray(matrix) || matrix.length === 0) return;

  tbody.innerHTML = matrix.map(item => {
    const isBull = item.trend === 'BULLISH';
    const isBear = item.trend === 'BEARISH';
    const trendColor = isBull ? 'var(--lime)' : (isBear ? 'var(--red)' : 'var(--amber)');
    const sigColor = item.direction === 'LONG' ? 'var(--lime)' : (item.direction === 'SHORT' ? 'var(--red)' : 'var(--text-muted)');
    const score = item.score || 0;
    const scoreColor = score >= 50 ? 'var(--lime)' : (score >= 30 ? 'var(--cyan)' : 'var(--text-muted)');
    const isTopSetup = score >= 50;

    return `
      <tr style="${isTopSetup ? 'background:rgba(16,185,129,0.08);border-left:3px solid var(--lime);' : 'border-bottom:1px solid rgba(255,255,255,0.04);'}">
        <td style="padding:8px 10px;font-family:var(--font-mono);font-weight:700;">
          ${(item.symbol || '').replace('USDT', '')}<span style="color:var(--text-muted);font-size:9px;">/USDT</span>
          ${isTopSetup ? '<span style="color:var(--lime);font-size:9px;margin-left:4px;font-weight:800;">★ TOP</span>' : ''}
        </td>
        <td style="padding:8px 10px;text-align:right;font-family:var(--font-mono);">$${parseFloat(item.price || 0).toLocaleString(undefined, {minimumFractionDigits: 2, maximumFractionDigits: 4})}</td>
        <td style="padding:8px 10px;text-align:center;font-family:var(--font-mono);color:${parseFloat(item.rsi) < 35 ? 'var(--lime)' : (parseFloat(item.rsi) > 65 ? 'var(--red)' : 'var(--text-secondary)')};">${item.rsi || '–'}</td>
        <td style="padding:8px 10px;text-align:center;font-family:var(--font-mono);color:${trendColor};font-weight:600;">${item.trend || 'RANGE'}</td>
        <td style="padding:8px 10px;text-align:center;font-family:var(--font-mono);color:${sigColor};font-weight:700;">${item.direction || 'NEUTRAL'}</td>
        <td style="padding:8px 10px;text-align:right;font-family:var(--font-mono);color:${scoreColor};font-weight:800;">
          ${score}%
        </td>
      </tr>
    `;
  }).join('');

  const timeEl = document.getElementById('matrix-updated-time');
  if (timeEl) timeEl.textContent = `● UPDATED ${new Date().toLocaleTimeString()}`;
}

/* ── UI Updaters ─────────────────────────────────────────────────── */
function updateBotToggleButton(isRunning) {
  const btn = document.getElementById('toggle-bot-btn');
  if (!btn) return;
  if (isRunning) {
    btn.textContent = '⏹ STOP ENGINE';
    btn.style.background = 'var(--red)';
    btn.style.color = '#ffffff';
  } else {
    btn.textContent = '▶ START ENGINE';
    btn.style.background = 'var(--lime)';
    btn.style.color = '#06080a';
  }
}

function updateHealth(data) {
  const hApi = document.getElementById('h-api');
  const hMode = document.getElementById('h-mode');
  const hBot = document.getElementById('h-bot');
  const hLic = document.getElementById('h-license');

  if (hApi) {
    const hasKeys = data.apiKey && data.apiSecret;
    hApi.textContent = hasKeys ? 'CONNECTED' : 'NOT SET';
    hApi.className = `h-val ${hasKeys ? 'ok' : 'bad'}`;
  }
  if (hMode) {
    const isTest = data.useTestnet === true;
    hMode.textContent = isTest ? 'TESTNET' : 'MAINNET';
    hMode.className = `h-val ${isTest ? 'cyan' : 'amber'}`;
  }
  if (hBot) {
    const isRun = data.botRunning === true;
    hBot.textContent = isRun ? 'ACTIVE' : 'STANDBY';
    hBot.className = `h-val ${isRun ? 'ok' : 'bad'}`;
  }
  if (hLic) {
    hLic.textContent = 'BOUND PRO';
    hLic.className = 'h-val ok';
  }
}

function updateMetrics(data) {
  const balEl = document.getElementById('ov-balance');
  const pnlEl = document.getElementById('ov-pnl');
  const barEl = document.getElementById('target-progress-bar');
  const statusEl = document.getElementById('ov-status');

  if (balEl && data.walletBalance) {
    balEl.textContent = `${parseFloat(data.walletBalance).toFixed(2)} USDT`;
  }
  if (pnlEl && data.dailyPnl !== undefined) {
    const pnl = parseFloat(data.dailyPnl);
    pnlEl.textContent = `${pnl >= 0 ? '+' : ''}$${pnl.toFixed(2)}`;
    pnlEl.style.color = pnl >= 0 ? 'var(--lime)' : 'var(--red)';
    
    // Target calculation (e.g., 25% daily target)
    if (barEl) {
      const targetPct = Math.min(100, Math.max(0, (pnl / 25) * 100));
      barEl.style.width = `${targetPct}%`;
    }
  }
  if (statusEl) {
    statusEl.textContent = data.botRunning ? 'ACTIVE SCANNING' : 'STANDBY';
    statusEl.style.color = data.botRunning ? 'var(--lime)' : 'var(--amber)';
  }
}

function updateDailyPnl(value) {
  const el = document.getElementById('ov-daily-pnl');
  if (!el) return;
  const pnl = parseFloat(value || 0);
  el.textContent = `${pnl >= 0 ? '+' : ''}$${pnl.toFixed(2)}`;
  el.style.color = pnl >= 0 ? 'var(--lime)' : 'var(--red)';
  // Update today's reset info
  const info = document.getElementById('daily-reset-info');
  if (info) {
    const midnight = new Date();
    midnight.setHours(24, 0, 0, 0);
    const hoursLeft = Math.ceil((midnight - Date.now()) / 3600000);
    info.textContent = `Resets in ${hoursLeft}h`;
  }
}

function updateScanPanel(state) {
  if (!state) return;
  const symEl    = document.getElementById('scan-current-sym');
  const rsiEl    = document.getElementById('scan-rsi');
  const ema50El  = document.getElementById('scan-ema50');
  const dirEl    = document.getElementById('scan-direction');
  const scoreEl  = document.getElementById('scan-score');
  const scorePct = document.getElementById('scan-score-pct');
  const scoreBar = document.getElementById('scan-progress-bar');
  const lastSig  = document.getElementById('scan-last-signal');
  const pulseEl  = document.getElementById('scan-pulse');
  const stratEl  = document.getElementById('scan-strategy-badge');
  const wlEl     = document.getElementById('scan-watchlist');

  // Scanning pulse
  if (pulseEl) {
    if (state.scanning) {
      pulseEl.classList.add('scan-pulse-active');
    } else {
      pulseEl.classList.remove('scan-pulse-active');
      pulseEl.style.background = 'var(--text-muted)';
    }
  }

  // Strategy badge
  if (stratEl && state.strategy) stratEl.textContent = state.strategy;

  // Watchlist pills
  if (wlEl && state.pairs && state.pairs.length) {
    wlEl.innerHTML = state.pairs.map(p =>
      `<span class="wl-pill ${state.currentSymbol === p ? 'active' : ''}">${p.replace('USDT','')}</span>`
    ).join('');
  } else if (wlEl && state.currentSymbol) {
    // Just highlight current symbol
    wlEl.querySelectorAll('.wl-pill').forEach(pill => {
      const sym = pill.textContent + 'USDT';
      pill.classList.toggle('active', sym === state.currentSymbol);
    });
  }

  // Current symbol being analyzed
  if (symEl && state.currentSymbol) {
    symEl.textContent = state.currentSymbol.replace('USDT', '/USDT');
  }

  // Indicator values
  if (rsiEl && state.rsi) {
    const rsi = parseFloat(state.rsi);
    rsiEl.textContent = rsi.toFixed(1);
    rsiEl.style.color = rsi < 35 ? 'var(--lime)' : rsi > 65 ? 'var(--red)' : 'var(--amber)';
  }
  if (ema50El && state.ema50) ema50El.textContent = `$${parseFloat(state.ema50).toFixed(2)}`;

  // Direction signal
  if (dirEl && state.direction) {
    dirEl.textContent = state.direction;
    dirEl.style.color = state.direction === 'LONG' ? 'var(--lime)' : 'var(--red)';
  } else if (dirEl && !state.direction) {
    dirEl.textContent = '–';
    dirEl.style.color = 'var(--text-muted)';
  }

  // Score
  const score = state.score || 0;
  if (scoreEl) {
    scoreEl.textContent = `${score}%`;
    scoreEl.style.color = score >= 70 ? 'var(--lime)' : score >= 50 ? 'var(--amber)' : 'var(--red)';
  }
  if (scorePct) scorePct.textContent = `${score}%`;
  if (scoreBar) {
    scoreBar.style.width = `${Math.min(100, score)}%`;
    scoreBar.style.background = score >= 70 ? 'var(--lime)' : score >= 50 ? 'var(--amber)' : 'var(--red)';
  }

  // Last signal found
  if (lastSig && state.lastSignal) {
    const ls = state.lastSignal;
    if (ls) {
      lastSig.textContent = `${(ls.symbol || '').replace('USDT','')} ${ls.dir || ''}${ls.score ? ` (${ls.score}%)` : ''}`;
      lastSig.style.color = ls.dir === 'LONG' ? 'var(--lime)' : 'var(--red)';
    }
  } else if (lastSig && state.lastSignal === null) {
    lastSig.textContent = 'None yet';
    lastSig.style.color = 'var(--text-muted)';
  }
}

function renderPosition(pos) {
  const noPosMsg = document.getElementById('no-pos-msg');
  const posDetails = document.getElementById('pos-details');
  if (!noPosMsg || !posDetails) return;

  if (!pos) {
    noPosMsg.style.display = 'block';
    noPosMsg.classList.remove('hidden');
    posDetails.style.display = 'none';
    posDetails.classList.add('hidden');
    return;
  }

  noPosMsg.style.display = 'none';
  noPosMsg.classList.add('hidden');
  posDetails.style.display = 'block';
  posDetails.classList.remove('hidden');

  const symEl = document.getElementById('pos-symbol');
  const dirEl = document.getElementById('pos-dir');
  const pnlEl = document.getElementById('pos-pnl');
  const entEl = document.getElementById('pos-entry');
  const curEl = document.getElementById('pos-current');
  const tpEl  = document.getElementById('pos-tp');
  const slEl  = document.getElementById('pos-sl');

  if (symEl) symEl.textContent = pos.symbol || 'BTCUSDT';
  if (dirEl) {
    dirEl.textContent = `${pos.direction} ${pos.leverage || 10}x [${pos.mode || 'PAPER'}]`;
    dirEl.className = `dir-tag ${pos.direction === 'LONG' ? 'long' : 'short'}`;
  }
  if (pnlEl) {
    const pnl = parseFloat(pos.pnl || 0);
    const pnlPct = parseFloat(pos.pnlPct || 0);
    pnlEl.textContent = `${pnl >= 0 ? '+' : ''}$${pnl.toFixed(2)} (${pnlPct >= 0 ? '+' : ''}${pnlPct.toFixed(2)}%)`;
    pnlEl.style.color = pnl >= 0 ? 'var(--lime)' : 'var(--red)';
  }
  if (entEl) entEl.textContent = `$${parseFloat(pos.entry || 0).toFixed(2)}`;
  if (curEl) curEl.textContent = `$${parseFloat(pos.currentPrice || pos.entry || 0).toFixed(2)}`;
  if (tpEl)  tpEl.textContent  = `$${parseFloat(pos.tp || 0).toFixed(2)}`;
  if (slEl)  slEl.textContent  = `$${parseFloat(pos.sl || 0).toFixed(2)}`;
}

function renderHistory(trades) {
  const box = document.getElementById('trade-history-table');
  if (!box) return;

  // Update summary stats
  updateExecStats(trades);

  if (!trades || trades.length === 0) {
    box.innerHTML = '<div class="empty-state" style="margin:40px 0;">No closed trade executions recorded yet.</div>';
    return;
  }

  let html = `
    <table>
      <thead>
        <tr>
          <th>TIME</th>
          <th>PAIR</th>
          <th>DIR</th>
          <th>ENTRY</th>
          <th>EXIT</th>
          <th>RESULT</th>
          <th style="text-align:right;">NET P&amp;L</th>
        </tr>
      </thead>
      <tbody>
  `;

  trades.slice().reverse().forEach(t => {
    const pnl = parseFloat(t.pnl || 0);
    const pnlColor = pnl >= 0 ? 'var(--lime)' : 'var(--red)';
    const resultBadge = pnl >= 0
      ? '<span style="font-size:9px;padding:3px 7px;border-radius:3px;background:rgba(163,230,53,0.12);color:var(--lime);border:1px solid rgba(163,230,53,0.3);font-weight:700;letter-spacing:1px;">WIN</span>'
      : '<span style="font-size:9px;padding:3px 7px;border-radius:3px;background:rgba(239,68,68,0.12);color:var(--red);border:1px solid rgba(239,68,68,0.3);font-weight:700;letter-spacing:1px;">LOSS</span>';

    // Format timestamp: t.time can be a number (ms), ISO string, or readable string
    let timeStr = '–';
    if (t.closeTime || t.time) {
      const ts = t.closeTime || t.time;
      try {
        const d = (typeof ts === 'number') ? new Date(ts) : new Date(ts);
        if (!isNaN(d.getTime())) {
          timeStr = d.toLocaleString('en-GB', {
            day: '2-digit', month: 'short',
            hour: '2-digit', minute: '2-digit'
          });
        } else {
          timeStr = String(ts).substring(0, 16);
        }
      } catch(e) { timeStr = String(ts).substring(0, 16); }
    }

    const entryPrice = parseFloat(t.entry || t.entryPrice || 0);
    const exitPrice  = parseFloat(t.exitPrice || t.exit || 0);

    html += `
      <tr>
        <td style="color:var(--text-muted);white-space:nowrap;">${timeStr}</td>
        <td style="font-weight:700;">${t.symbol || 'BTCUSDT'}</td>
        <td><span class="dir-tag ${t.direction === 'LONG' ? 'long' : 'short'}">${t.direction || '–'}</span></td>
        <td>$${entryPrice.toFixed(2)}</td>
        <td>$${exitPrice.toFixed(2)}</td>
        <td>${resultBadge}</td>
        <td style="text-align:right;font-weight:700;color:${pnlColor};">${pnl >= 0 ? '+' : ''}$${pnl.toFixed(2)}</td>
      </tr>
    `;
  });

  html += '</tbody></table>';
  box.innerHTML = html;
}

function updateExecStats(trades) {
  const total    = document.getElementById('stat-total');
  const winrate  = document.getElementById('stat-winrate');
  const wl       = document.getElementById('stat-wl');
  const netPnl   = document.getElementById('stat-pnl');
  if (!total) return;

  const t = trades || [];
  const wins   = t.filter(x => parseFloat(x.pnl || 0) >= 0).length;
  const losses  = t.length - wins;
  const totalPnl = t.reduce((sum, x) => sum + parseFloat(x.pnl || 0), 0);
  const wr = t.length > 0 ? Math.round((wins / t.length) * 100) : 0;

  total.textContent   = t.length;
  winrate.textContent = `${wr}%`;
  winrate.style.color = wr >= 50 ? 'var(--lime)' : 'var(--amber)';
  wl.innerHTML        = `<span style="color:var(--lime)">${wins}</span> / <span style="color:var(--red)">${losses}</span>`;
  netPnl.textContent  = `${totalPnl >= 0 ? '+' : ''}$${totalPnl.toFixed(2)}`;
  netPnl.style.color  = totalPnl >= 0 ? 'var(--lime)' : 'var(--red)';
}

function appendLog(line) {
  const box = document.getElementById('live-log-box');
  if (!box) return;
  const time = new Date().toLocaleTimeString();
  const d = document.createElement('div');
  d.className = 'log-line';
  d.textContent = `[${time}] ${line}`;
  box.appendChild(d);
  box.scrollTop = box.scrollHeight;
}

function startCycleTimer(cycle) {
  if (CYCLE_TIMER_INTERVAL) clearInterval(CYCLE_TIMER_INTERVAL);
  const timerEl = document.getElementById('ov-timer');
  if (!timerEl) return;

  const update = () => {
    const now = Date.now();
    const duration = 12 * 3600 * 1000; // 12H cycle
    const start = (cycle && cycle.startTime) ? cycle.startTime : now;
    const elapsed = (now - start) % duration;
    const remaining = Math.max(0, duration - elapsed);

    const h = Math.floor(remaining / 3600000);
    const m = Math.floor((remaining % 3600000) / 60000);
    const s = Math.floor((remaining % 60000) / 1000);
    timerEl.textContent = `${h.toString().padStart(2, '0')}:${m.toString().padStart(2, '0')}:${s.toString().padStart(2, '0')}`;
  };

  update();
  CYCLE_TIMER_INTERVAL = setInterval(update, 1000);
}

/* ── Event Listeners ──────────────────────────────────────────────── */
function initListeners() {
  // Toggle Bot Engine
  const toggleBotBtn = document.getElementById('toggle-bot-btn');
  if (toggleBotBtn) {
    toggleBotBtn.addEventListener('click', async () => {
      toggleBotBtn.disabled = true;
      const d = await chrome.storage.local.get(['botRunning', 'selectedStrategy', 'savedSettings', 'tradeSettings']);
      const willRun = !d.botRunning;
      const action = willRun ? 'START_BOT' : 'STOP_BOT';
      const strategy = d.selectedStrategy || 'Completed-Candle';
      const settings = d.tradeSettings || d.savedSettings || {};

      chrome.runtime.sendMessage({ action, strategy, settings }, () => {
        toggleBotBtn.disabled = false;
        updateBotToggleButton(willRun);
        const statusEl = document.getElementById('ov-status');
        if (statusEl) {
          statusEl.textContent = willRun ? 'ACTIVE SCANNING' : 'STANDBY';
          statusEl.style.color = willRun ? 'var(--lime)' : 'var(--amber)';
        }
      });
    });
  }

  function updateTestnetHint() {
    const isTest = document.getElementById('testnet-toggle')?.checked;
    const hint = document.getElementById('testnet-status-hint');
    if (!hint) return;
    if (isTest) {
      hint.innerHTML = '<span style="color:var(--amber);font-weight:700;">⚠️ TESTNET MODE ACTIVE:</span> Only works with keys created on <a href="https://testnet.binancefuture.com" target="_blank" style="color:var(--lime);text-decoration:underline;">testnet.binancefuture.com</a>.<br>👉 If you created your API key on your real <b>Binance.com</b> account, <b>UNCHECK this box</b>!';
      hint.style.borderColor = 'rgba(245,158,11,0.4)';
      hint.style.background = 'rgba(245,158,11,0.08)';
      hint.style.color = 'var(--text-primary)';
    } else {
      hint.innerHTML = '<span style="color:var(--lime);font-weight:700;">🌐 MAINNET (LIVE) ACTIVE:</span> Connected to live Binance Futures (<code style="color:var(--lime);">fapi.binance.com</code>). Ready for real live execution.';
      hint.style.borderColor = 'rgba(16,185,129,0.4)';
      hint.style.background = 'rgba(16,185,129,0.08)';
      hint.style.color = 'var(--text-primary)';
    }
  }

  async function autoSaveApiKeys() {
    const keyInput = document.getElementById('api-key-input');
    const secInput = document.getElementById('api-secret-input');
    const testnetTog = document.getElementById('testnet-toggle');
    if (!keyInput || !secInput) return;

    let apiKey = keyInput.value.trim().replace(/^["']|["']$/g, '');
    let apiSecret = secInput.value.trim().replace(/^["']|["']$/g, '');
    const useTestnet = testnetTog ? testnetTog.checked : false;

    if (apiKey) localStorage.setItem('nexus_apiKey', apiKey);
    if (apiSecret) localStorage.setItem('nexus_apiSecret', apiSecret);
    localStorage.setItem('nexus_useTestnet', useTestnet);

    await chrome.storage.local.set({ apiKey, apiSecret, useTestnet });
    chrome.runtime.sendMessage({ action: 'UPDATE_CONFIG', apiKey, apiSecret, useTestnet });

    const apiSavedBanner = document.getElementById('api-saved-banner');
    const saveApiBtn = document.getElementById('save-api-btn');
    if (apiKey && apiSecret) {
      if (apiSavedBanner) apiSavedBanner.classList.remove('hidden');
      if (saveApiBtn) {
        saveApiBtn.textContent = '✓ Keys Permanently Saved';
        saveApiBtn.style.background = 'rgba(16,185,129,0.2)';
        saveApiBtn.style.borderColor = 'var(--lime)';
        saveApiBtn.style.color = 'var(--lime)';
      }
    }
  }

  const apiKeyInp = document.getElementById('api-key-input');
  const apiSecInp = document.getElementById('api-secret-input');
  if (apiKeyInp) {
    apiKeyInp.addEventListener('input', autoSaveApiKeys);
    apiKeyInp.addEventListener('change', autoSaveApiKeys);
    apiKeyInp.addEventListener('blur', autoSaveApiKeys);
  }
  if (apiSecInp) {
    apiSecInp.addEventListener('input', autoSaveApiKeys);
    apiSecInp.addEventListener('change', autoSaveApiKeys);
    apiSecInp.addEventListener('blur', autoSaveApiKeys);
  }

  // Toggle Secret Visibility
  const toggleSecBtn = document.getElementById('toggle-secret-visibility');
  const toggleSecTxt = document.getElementById('toggle-secret-text');
  if (toggleSecBtn && apiSecInp) {
    toggleSecBtn.addEventListener('click', () => {
      if (apiSecInp.type === 'password') {
        apiSecInp.type = 'text';
        if (toggleSecTxt) toggleSecTxt.textContent = 'Hide Secret';
      } else {
        apiSecInp.type = 'password';
        if (toggleSecTxt) toggleSecTxt.textContent = 'Show Secret';
      }
    });
  }

  const testnetToggle = document.getElementById('testnet-toggle');
  if (testnetToggle) {
    testnetToggle.addEventListener('change', () => {
      updateTestnetHint();
      autoSaveApiKeys();
    });
  }

  // Save API
  const saveApiBtn = document.getElementById('save-api-btn');
  if (saveApiBtn) {
    saveApiBtn.addEventListener('click', async () => {
      let apiKey = document.getElementById('api-key-input').value.trim().replace(/^["']|["']$/g, '');
      let apiSecret = document.getElementById('api-secret-input').value.trim().replace(/^["']|["']$/g, '');
      const useTestnet = document.getElementById('testnet-toggle').checked;
      document.getElementById('api-key-input').value = apiKey;
      document.getElementById('api-secret-input').value = apiSecret;

      if (apiKey && apiSecret && apiKey === apiSecret) {
        alert('❌ Error: API Key aur API Secret dono dabbon mein ek jaisi paste ho gayi hain!\n\nBinance par Secret Key alag hoti hai. Please apni asal Secret Key paste karein.');
        return;
      }
      
      localStorage.setItem('nexus_apiKey', apiKey);
      localStorage.setItem('nexus_apiSecret', apiSecret);
      localStorage.setItem('nexus_useTestnet', useTestnet);

      await chrome.storage.local.set({ apiKey, apiSecret, useTestnet });
      chrome.runtime.sendMessage({ action: 'UPDATE_CONFIG', apiKey, apiSecret, useTestnet }, (resp) => {
        if (resp && resp.balance !== undefined) {
          const balEl = document.getElementById('ov-balance');
          if (balEl) balEl.textContent = `${parseFloat(resp.balance).toFixed(2)} USDT`;
        }
        loadInitialState();
      });

      const apiSavedBanner = document.getElementById('api-saved-banner');
      if (apiSavedBanner) apiSavedBanner.classList.remove('hidden');
      saveApiBtn.textContent = '✓ Keys Permanently Saved';
      saveApiBtn.style.background = 'rgba(16,185,129,0.2)';
      saveApiBtn.style.borderColor = 'var(--lime)';
      saveApiBtn.style.color = 'var(--lime)';

      let modeMsg = useTestnet ? 'TESTNET (testnet.binancefuture.com)' : 'LIVE MAINNET (fapi.binance.com)';
      alert(`✅ Binance API Keys Saved!\nMode: ${modeMsg}\n\n👉 Now click "Test Connection" to verify your wallet balance.`);
    });
  }

  // Test API
  const testApiBtn = document.getElementById('test-api-btn');
  if (testApiBtn) {
    testApiBtn.addEventListener('click', async () => {
      const resEl = document.getElementById('api-test-result');
      resEl.classList.remove('hidden');
      resEl.textContent = '⏳ Testing Binance Futures connection & balance...';
      resEl.style.color = 'var(--text-secondary)';

      chrome.runtime.sendMessage({ action: 'TEST_API' }, (resp) => {
        if (resp && resp.ok) {
          resEl.innerHTML = `✅ <b>Connection Successful!</b> Futures Wallet Balance: <b style="color:var(--lime);">${resp.balance} USDT</b>`;
          resEl.style.color = 'var(--lime)';
          resEl.style.background = 'rgba(16,185,129,0.1)';
          resEl.style.border = '1px solid rgba(16,185,129,0.3)';
          const balEl = document.getElementById('ov-balance');
          if (balEl) balEl.textContent = `${parseFloat(resp.balance).toFixed(2)} USDT`;
        } else {
          const errMsg = resp?.error || 'Authentication failed';
          let diag = '';
          if (errMsg.includes('-1022') || errMsg.includes('Signature')) {
            diag = `<div style="margin-top:6px;font-size:11px;color:var(--text-secondary);line-height:1.5;">
              <b>Troubleshooting Signature Error (-1022):</b><br>
              1. <b>Mainnet vs Testnet:</b> If your keys are from your real Binance account, <b>UNCHECK 'Use Binance Futures Testnet'</b> above and click Save.<br>
              2. <b>Secret Key:</b> Ensure you copied the Secret Key correctly when creating the API key (Binance only shows it once).<br>
              3. <b>Permissions:</b> In Binance API Management, ensure <b>'Enable Futures'</b> is checked.
            </div>`;
          }
          resEl.innerHTML = `❌ <b>Connection Failed:</b> ${errMsg}${diag}`;
          resEl.style.color = 'var(--red)';
          resEl.style.background = 'rgba(239,68,68,0.1)';
          resEl.style.border = '1px solid rgba(239,68,68,0.3)';
        }
      });
    });
  }

  // Live Multi-Pair Market Scanner Trigger
  const scanNowBtn = document.getElementById('scan-now-btn');
  if (scanNowBtn) {
    scanNowBtn.addEventListener('click', async () => {
      scanNowBtn.disabled = true;
      scanNowBtn.textContent = '⏳ Scanning 10 Pairs...';
      try {
        chrome.runtime.sendMessage({ action: 'SCAN_NOW' }, (resp) => {
          if (resp && resp.matrix) {
            updateMarketMatrix(resp.matrix);
          }
          setTimeout(() => {
            scanNowBtn.disabled = false;
            scanNowBtn.textContent = '⚡ SCAN MARKETS NOW';
          }, 1200);
        });
      } catch (e) {
        scanNowBtn.disabled = false;
        scanNowBtn.textContent = '⚡ SCAN MARKETS NOW';
      }
    });
  }

  // Auto-save strategy settings on change
  ['strategy-input', 'symbol-input', 'amount-input', 'leverage-input', 'sl-input', 'tp-input', 'mode-input', 'multiscan-input', 'timeframe-input'].forEach(id => {
    const el = document.getElementById(id);
    if (el) {
      el.addEventListener('change', async () => {
        const s = {
          symbol: document.getElementById('symbol-input')?.value.trim().toUpperCase() || 'BTCUSDT',
          amount: document.getElementById('amount-input')?.value.trim() || '100',
          leverage: document.getElementById('leverage-input')?.value || '10',
          stopLoss: document.getElementById('sl-input')?.value || '1.5',
          takeProfit: document.getElementById('tp-input')?.value || '3.0',
          mode: document.getElementById('mode-input')?.value || 'paper',
          multiScan: document.getElementById('multiscan-input')?.value || 'enabled',
          timeframe: document.getElementById('timeframe-input')?.value || '1h'
        };
        const strat = document.getElementById('strategy-input')?.value || 'Completed-Candle';
        localStorage.setItem('nexus_tradeSettings', JSON.stringify(s));
        localStorage.setItem('nexus_selectedStrategy', strat);
        await chrome.storage.local.set({ tradeSettings: s, savedSettings: s, selectedStrategy: strat });
        chrome.runtime.sendMessage({ action: 'UPDATE_CONFIG', strategy: strat, settings: s });
      });
    }
  });

  // Save Strategy Settings
  const saveSettingsBtn = document.getElementById('save-settings-btn');
  if (saveSettingsBtn) {
    saveSettingsBtn.addEventListener('click', async () => {
      const s = {
        symbol: document.getElementById('symbol-input').value.trim().toUpperCase(),
        amount: document.getElementById('amount-input').value.trim(),
        leverage: document.getElementById('leverage-input').value,
        stopLoss: document.getElementById('sl-input').value,
        takeProfit: document.getElementById('tp-input').value,
        mode: document.getElementById('mode-input').value,
        multiScan: document.getElementById('multiscan-input')?.value || 'enabled',
        timeframe: document.getElementById('timeframe-input')?.value || '1h'
      };
      const strat = document.getElementById('strategy-input')?.value || 'Completed-Candle';
      localStorage.setItem('nexus_tradeSettings', JSON.stringify(s));
      localStorage.setItem('nexus_selectedStrategy', strat);
      await chrome.storage.local.set({ tradeSettings: s, savedSettings: s, selectedStrategy: strat });
      chrome.runtime.sendMessage({ action: 'UPDATE_CONFIG', strategy: strat, settings: s }, (resp) => {
        if (resp && resp.balance !== undefined) {
          const balEl = document.getElementById('ov-balance');
          if (balEl) balEl.textContent = `${parseFloat(resp.balance).toFixed(2)} USDT`;
        }
        loadInitialState();
      });
      alert(`Strategy Configuration Saved!\nActive Strategy: ${strat}\nMode: ${s.mode.toUpperCase()}`);
    });
  }

  // Copy Device ID
  const copyDevBtn = document.getElementById('copy-device-btn');
  if (copyDevBtn) {
    copyDevBtn.addEventListener('click', () => {
      const devId = document.getElementById('device-id-display').value;
      navigator.clipboard.writeText(devId);
      alert('Device ID Copied to Clipboard!');
    });
  }

  // Auto-save & auto-validate License Key
  const licenseKeyInp = document.getElementById('license-key-input');
  if (licenseKeyInp) {
    licenseKeyInp.addEventListener('input', () => {
      const k = licenseKeyInp.value.trim().toUpperCase();
      if (k) {
        localStorage.setItem('nexus_licenseKey', k);
        chrome.storage.local.set({ licenseKey: k });
      }
    });
    licenseKeyInp.addEventListener('change', () => {
      const k = licenseKeyInp.value.trim().toUpperCase();
      if (k) {
        localStorage.setItem('nexus_licenseKey', k);
        chrome.storage.local.set({ licenseKey: k, licenseValid: true });
        chrome.runtime.sendMessage({ action: 'ACTIVATE_LICENSE', key: k });
        const licBanner = document.getElementById('license-active-banner');
        const licTag = document.getElementById('license-saved-tag');
        if (licBanner) licBanner.classList.remove('hidden');
        if (licTag) licTag.classList.remove('hidden');
        const actBtn = document.getElementById('activate-btn');
        if (actBtn) {
          actBtn.textContent = 'Licence Active ✓';
          actBtn.style.background = 'rgba(16,185,129,0.2)';
          actBtn.style.borderColor = 'var(--lime)';
          actBtn.style.color = 'var(--lime)';
        }
      }
    });
  }

  // Activate Licence
  const actBtn = document.getElementById('activate-btn');
  if (actBtn) {
    actBtn.addEventListener('click', () => {
      const key = document.getElementById('license-key-input').value.trim().toUpperCase();
      const msgEl = document.getElementById('license-status-msg');
      msgEl.classList.remove('hidden');
      msgEl.textContent = '⏳ Verifying licence with Nexus Cloudflare Worker...';
      msgEl.style.color = 'var(--text-secondary)';

      chrome.runtime.sendMessage({ action: 'ACTIVATE_LICENSE', key }, (resp) => {
        if (resp && resp.valid) {
          localStorage.setItem('nexus_licenseKey', key);
          localStorage.setItem('nexus_licenseActive', 'true');
          chrome.storage.local.set({ licenseKey: key, licenseValid: true });
          msgEl.textContent = '✅ Licence Activated & Permanently Bound to this Device!';
          msgEl.style.color = 'var(--lime)';

          const licBanner = document.getElementById('license-active-banner');
          const licTag = document.getElementById('license-saved-tag');
          if (licBanner) licBanner.classList.remove('hidden');
          if (licTag) licTag.classList.remove('hidden');
          actBtn.textContent = 'Licence Active ✓';
          actBtn.style.background = 'rgba(16,185,129,0.2)';
          actBtn.style.borderColor = 'var(--lime)';
          actBtn.style.color = 'var(--lime)';
        } else {
          msgEl.textContent = `❌ Activation Failed: ${resp?.msg || 'Invalid Key'}`;
          msgEl.style.color = 'var(--red)';
        }
      });
    });
  }

  // Close Position
  const closePosBtn = document.getElementById('close-pos-btn');
  if (closePosBtn) {
    closePosBtn.addEventListener('click', () => {
      closePosBtn.disabled = true;
      closePosBtn.textContent = 'Closing...';
      chrome.runtime.sendMessage({ action: 'CLOSE_POSITION' }, () => {
        closePosBtn.disabled = false;
        closePosBtn.textContent = 'Market Close Position';
        renderPosition(null);
      });
    });
  }

  // Force Clear
  const forceClearBtn = document.getElementById('force-clear-btn');
  if (forceClearBtn) {
    forceClearBtn.addEventListener('click', () => {
      chrome.runtime.sendMessage({ action: 'FORCE_CLEAR' }, () => {
        renderPosition(null);
      });
      renderPosition(null);
    });
  }

  // Trigger Immediate Test Trade
  const testTradeBtn = document.getElementById('trigger-test-trade-btn');
  if (testTradeBtn) {
    testTradeBtn.addEventListener('click', () => {
      testTradeBtn.disabled = true;
      testTradeBtn.textContent = '⏳ Executing Test Trade...';
      const sym = document.getElementById('symbol-input')?.value.trim().toUpperCase() || 'BTCUSDT';
      appendLog(`⚡ Immediate test trade triggered for ${sym}...`);
      chrome.runtime.sendMessage({ action: 'FORCE_TRADE', symbol: sym, direction: 'LONG' }, (resp) => {
        testTradeBtn.disabled = false;
        testTradeBtn.textContent = '⚡ Open Immediate Test Trade (Verify Execution)';
        if (resp && resp.ok) {
          appendLog(`✅ Test trade executed successfully! Position open for ${sym}.`);
          loadInitialState();
        } else {
          const errText = resp?.error || 'Failed to open test trade';
          appendLog(`❌ Test trade failed: ${errText}`);
          alert('Trade Notice: ' + errText);
        }
      });
    });
  }

  // Clear History
  const clearHistBtn = document.getElementById('clear-history-btn');
  if (clearHistBtn) {
    clearHistBtn.addEventListener('click', async () => {
      if (confirm('Clear execution history?')) {
        await chrome.storage.local.set({ tradeHistory: [] });
        renderHistory([]);
      }
    });
  }

  // Refresh Button
  const refreshBtn = document.getElementById('refresh-btn');
  if (refreshBtn) {
    refreshBtn.addEventListener('click', () => loadInitialState());
  }

  // Save Gemini Key
  const saveGeminiBtn = document.getElementById('save-gemini-btn');
  if (saveGeminiBtn) {
    saveGeminiBtn.addEventListener('click', async () => {
      const geminiKey = document.getElementById('gemini-key-input')?.value.trim() || '';
      await chrome.storage.local.set({ geminiKey });
      chrome.runtime.sendMessage({ action: 'UPDATE_CONFIG' });
      const msg = document.getElementById('gemini-status-msg');
      if (msg) {
        msg.textContent = '✅ Gemini API Key Saved & Bound to Oracle!';
        msg.style.display = 'block';
      }
      alert('Gemini API Key Saved Successfully!');
    });
  }

  // Chat AI Oracle
  const chatFab = document.getElementById('chat-toggle-btn');
  const chatPanel = document.getElementById('chat-panel');
  const chatClose = document.getElementById('chat-close-btn');
  const chatSend = document.getElementById('chat-send-btn');
  const chatInput = document.getElementById('chat-input');
  const chatMessages = document.getElementById('chat-messages');

  if (chatFab && chatPanel) {
    chatFab.addEventListener('click', () => chatPanel.classList.toggle('hidden'));
    if (chatClose) chatClose.addEventListener('click', () => chatPanel.classList.add('hidden'));

    const sendChat = (customText) => {
      const q = (typeof customText === 'string' ? customText : chatInput.value).trim();
      if (!q) return;
      chatInput.value = '';

      const uD = document.createElement('div');
      uD.className = 'chat-bubble user';
      uD.textContent = q;
      chatMessages.appendChild(uD);

      const loadingBubble = document.createElement('div');
      loadingBubble.className = 'chat-bubble bot';
      loadingBubble.textContent = '⏳ Analyzing live Binance market data & calculating Entry/SL/TP levels...';
      chatMessages.appendChild(loadingBubble);
      chatMessages.scrollTop = chatMessages.scrollHeight;

      chrome.runtime.sendMessage({ action: 'CHAT_GEMINI', text: q }, (resp) => {
        loadingBubble.textContent = resp?.reply || 'Nexus AI Market Oracle analysis complete.';
        chatMessages.scrollTop = chatMessages.scrollHeight;
        if (resp?.reply && resp.reply.includes('Execution Order Placed')) {
          loadInitialState();
        }
      });
    };

    if (chatSend) chatSend.addEventListener('click', () => sendChat());
    if (chatInput) {
      chatInput.addEventListener('keydown', (e) => {
        if (e.key === 'Enter') sendChat();
      });
    }

    document.querySelectorAll('.chat-chip').forEach(btn => {
      btn.addEventListener('click', () => {
        sendChat(btn.dataset.query);
      });
    });
  }
}
