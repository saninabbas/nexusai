'use strict';
/* ══════════════════════════════════════════════════════════════════════
   NEXUS TRADER v5.1.0 – Popup Controller
══════════════════════════════════════════════════════════════════════ */

let selectedStrategy = 'Completed-Candle';
let botRunning = false;

document.addEventListener('DOMContentLoaded', async () => {
  await loadState();
  await checkApiKeys();
  initListeners();
  startRefresh();
});

function initListeners() {
  const startBtn = document.getElementById('start-btn');
  const dashBtn = document.getElementById('full-dashboard-btn');
  const badgeBtn = document.getElementById('premium-badge-btn');
  const setupLink = document.getElementById('api-setup-link');

  if (startBtn) startBtn.addEventListener('click', toggleBot);
  if (dashBtn) dashBtn.addEventListener('click', openDashboard);
  if (badgeBtn) badgeBtn.addEventListener('click', openDashboard);
  if (setupLink) setupLink.addEventListener('click', openDashboard);

  document.querySelectorAll('.strategy-card').forEach(card => {
    card.addEventListener('click', function () {
      selectStrategy(this.dataset.strategy);
    });
  });
}

async function loadState() {
  const d = await chrome.storage.local.get(['botRunning', 'selectedStrategy', 'activeTrade', 'walletBalance', 'dailyPnl']);
  botRunning = !!d.botRunning;
  setBotUI(botRunning);

  if (d.selectedStrategy) {
    selectedStrategy = d.selectedStrategy;
    highlightStrategy(selectedStrategy);
  }

  // Update Balance
  const balEl = document.getElementById('balance');
  const pnlEl = document.getElementById('today-pl');
  const tradesEl = document.getElementById('active-trades');

  if (balEl) {
    if (d.walletBalance !== undefined && d.walletBalance !== null) {
      balEl.textContent = `${parseFloat(d.walletBalance).toFixed(2)} USDT`;
    }
    // Query background for fresh live/demo balance
    chrome.runtime.sendMessage({ action: 'GET_BALANCE' }, (resp) => {
      if (resp && resp.balance !== undefined && balEl) {
        balEl.textContent = `${parseFloat(resp.balance).toFixed(2)} USDT`;
      }
    });
  }
  if (pnlEl && d.dailyPnl !== undefined) {
    const pnl = parseFloat(d.dailyPnl);
    pnlEl.textContent = `${pnl >= 0 ? '+' : ''}$${pnl.toFixed(2)}`;
    pnlEl.className = pnl >= 0 ? 'profit' : 'red-text';
  }
  if (tradesEl) {
    tradesEl.textContent = d.activeTrade ? '1' : '0';
  }
}

async function checkApiKeys() {
  const d = await chrome.storage.local.get(['apiKey', 'apiSecret']);
  const bar = document.getElementById('api-status-bar');
  if (!bar) return;

  if (d.apiKey && d.apiSecret) {
    bar.className = 'api-status-bar ok';
    bar.innerHTML = '✅ Binance Keys Configured — System Ready';
  } else {
    bar.className = 'api-status-bar no-api';
    bar.innerHTML = '⚠️ Binance Keys Not Configured — <span id="api-setup-link" class="link-text">Configure</span>';
    const link = document.getElementById('api-setup-link');
    if (link) link.addEventListener('click', openDashboard);
  }
}

async function toggleBot() {
  const d = await chrome.storage.local.get(['apiKey', 'tradeSettings']);
  const mode = d.tradeSettings?.mode || 'paper';

  if (mode === 'live' && !d.apiKey) {
    flashBar('⚠️ Configure Binance API keys for Live trading!', 'no-api');
    return;
  }

  botRunning = !botRunning;
  setBotUI(botRunning);

  await chrome.storage.local.set({ botRunning });
  chrome.runtime.sendMessage({
    action: botRunning ? 'START_BOT' : 'STOP_BOT',
    strategy: selectedStrategy
  });
}

function setBotUI(running) {
  const btn = document.getElementById('start-btn');
  const dot = document.getElementById('status-dot');
  const label = document.getElementById('bot-status');
  const btnText = document.getElementById('btn-text');

  if (!btn || !dot || !label) return;

  if (running) {
    dot.className = 'dot dot-on';
    label.textContent = 'ENGINE ACTIVE';
    label.style.color = 'var(--lime)';
    btn.className = 'start-btn running';
    btnText.textContent = 'STOP ENGINE';
  } else {
    dot.className = 'dot dot-off';
    label.textContent = 'ENGINE STANDBY';
    label.style.color = 'var(--text)';
    btn.className = 'start-btn';
    btnText.textContent = 'START ENGINE';
  }
}

async function selectStrategy(strat) {
  selectedStrategy = strat;
  highlightStrategy(strat);
  await chrome.storage.local.set({ selectedStrategy: strat });
  chrome.runtime.sendMessage({ action: 'SET_STRATEGY', strategy: strat });
}

function highlightStrategy(strat) {
  document.querySelectorAll('.strategy-card').forEach(card => {
    card.classList.toggle('active-strategy', card.dataset.strategy === strat);
  });
}

function openDashboard() {
  chrome.tabs.create({ url: chrome.runtime.getURL('dashboard.html') });
}

function flashBar(msg, cls) {
  const bar = document.getElementById('api-status-bar');
  if (!bar) return;
  bar.className = `api-status-bar ${cls}`;
  bar.textContent = msg;
}

function startRefresh() {
  setInterval(loadState, 3000);
}
